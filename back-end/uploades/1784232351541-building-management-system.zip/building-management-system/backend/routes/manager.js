const express = require("express");
const pool = require("../db"); // MySQL connection
const upload = require("../middleware/upload"); // Ensure correct import
const path = require("path");
const bcrypt = require("bcrypt");
const isAuthenticated = require("../middleware/auth"); // Import auth middleware
const moment = require("moment"); // Import moment
const router = express.Router();

// Manager Dashboard Route (Protected)
router.get("/dashboard", isAuthenticated("manager"), (req, res) => {
  res.render("manager_dashboard", { username: req.session.user.username });
});

// Route to display the manager profile
router.get("/manage/profile", isAuthenticated("manager"), async (req, res) => {
  const managerId = req.session.user.id;

  try {
    const [manager] = await pool.query(
      "SELECT username FROM users WHERE id = ?",
      [managerId]
    );

    if (manager.length === 0) {
      return res.redirect("/manager/dashboard?error=User not found.");
    }

    res.render("manager/manage_profile", {
      user: manager[0], // Only send the username
      error: req.query.error,
      success: req.query.success,
    });
  } catch (err) {
    console.error(err);
    res.redirect("/manager/dashboard?error=Failed to load profile.");
  }
});

//  Update Manager Profile Route
router.post(
  "/manage/profile/update",
  isAuthenticated("manager"),
  async (req, res) => {
    const { old_password, username, password } = req.body;
    const managerId = req.session.user.id; // Assuming session stores manager info

    try {
      // Fetch the current manager's stored password
      const [manager] = await pool.query(
        "SELECT password FROM users WHERE id = ?",
        [managerId]
      );

      if (manager.length === 0) {
        return res.redirect("/manager/manage/profile?error=User not found.");
      }

      const storedPassword = manager[0].password;

      // Verify the old password entered by the user
      const match = await bcrypt.compare(old_password, storedPassword);
      if (!match) {
        return res.redirect(
          "/manager/manage/profile?error=Incorrect old password."
        );
      }

      let updateFields = [];
      let values = [];

      if (username) {
        updateFields.push("username = ?");
        values.push(username);
      }

      if (password) {
        const hashedPassword = await bcrypt.hash(password, 10);
        updateFields.push("password = ?");
        values.push(hashedPassword);
      }

      values.push(managerId);

      if (updateFields.length > 0) {
        await pool.query(
          `UPDATE users SET ${updateFields.join(", ")} WHERE id = ?`,
          values
        );
      }

      res.redirect(
        "/manager/manage/profile?success=Profile updated successfully."
      );
    } catch (err) {
      console.error(err);
      res.redirect("/manager/manage/profile?error=Failed to update profile.");
    }
  }
);
//route to desplay manage payment
/* router.get("/tenant/payment", isAuthenticated("manager"), (req, res) => {
  res.render("manager/tenants_payment");
}); */
//route to display manage tenant menu
router.get("/tenant/menu", isAuthenticated("manager"), (req, res) => {
  res.render("manager/tenants_menu");
});

// This is where the tenant creation form will be
router.get("/tenants/create", isAuthenticated("manager"), (req, res) => {
  res.render("manager/create_tenants");
});
//route for employee menu
router.get("/employee/menu", isAuthenticated("manager"), (req, res) => {
  res.render("manager/employee_menu");
});
//route for displaying create employee form
router.get("/employee/create", isAuthenticated("manager"), (req, res) => {
  res.render("manager/create_employee", { error: null }); // Renders the create_room.ejs template
});

// Route to render the employee creation page
router.get("/employee/create", isAuthenticated("manager"), (req, res) => {
  res.render("manager/create_employee");
});

// Route to handle the employee creation form submission
router.post(
  "/employees/create",
  isAuthenticated("manager"),
  upload.fields([
    { name: "id_card", maxCount: 1 },
    { name: "co_signer_id_card", maxCount: 1 },
    { name: "co_signer_lease", maxCount: 1 },
  ]),
  async (req, res) => {
    const {
      fullname,
      age,
      gender,
      role,
      co_signer_fullname,
      salary,
      employment_date,
      contact_info,
      status,
      cosigner_contactinfo,
      employee_type,
      leave_days,
    } = req.body;

    // Retrieve filenames of uploaded images (if available)
    const idCardImage = req.files?.id_card
      ? req.files["id_card"][0].filename
      : null;
    const coSignerIdCardImage = req.files?.co_signer_id_card
      ? req.files["co_signer_id_card"][0].filename
      : null;
    const coSignerLease = req.files?.co_signer_lease
      ? req.files["co_signer_lease"][0].filename
      : null;

    // Set default leave_days to 15 if not provided
    const leaveDays = leave_days ? parseInt(leave_days, 10) : 15;

    console.log("Received data:", {
      fullname,
      age,
      gender,
      role,
      salary,
      employment_date,
      status,
      idCardImage,
      coSignerIdCardImage,
      coSignerLease,
      employee_type,
      leaveDays,
    });

    // Input validation
    if (
      !fullname ||
      !age ||
      !gender ||
      !role ||
      !salary ||
      !employment_date ||
      !status ||
      !idCardImage ||
      !coSignerIdCardImage ||
      !coSignerLease ||
      !employee_type
    ) {
      return res.render("manager/create_employee", {
        error: "All fields are required!",
      });
    }

    try {
      // Insert employee details into the database
      await pool.execute(
        `INSERT INTO employees 
        (fullname, id_card, age, gender, role, co_signer_fullname, co_signer_id_card, co_signer_lease, salary, employment_date, contact_info, status, cosigner_contactinfo, employment_type, leave_days)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          fullname,
          idCardImage,
          age,
          gender,
          role,
          co_signer_fullname,
          coSignerIdCardImage,
          coSignerLease,
          salary,
          employment_date,
          contact_info || null, // Ensure null instead of undefined
          status,
          cosigner_contactinfo || null, // Ensure null instead of undefined
          employee_type,
          leaveDays, // Ensure leaveDays is always defined
        ]
      );

      res.redirect(
        "/manager/employee/create?success=Employee created successfully!"
      );
    } catch (err) {
      console.error("Error creating employee:", err);
      res.render("manager/create_employee", {
        error: "Failed to create employee.",
      });
    }
  }
);

// Route to view a single employee
router.get("/employee/view", isAuthenticated("manager"), async (req, res) => {
  try {
    // Fetch employees from the database
    const [employees] = await pool.query(`
      SELECT * FROM employees where status != 'Terminated' AND role != 'Manager'
    `);

    // Format the date and other fields as needed
    employees.forEach((employee) => {
      employee.contact_info = employee.contact_info || "Not Provided"; // Ensure contact info is displayed
      employee.salary = employee.salary || "Not Set"; // Ensure salary is displayed
      employee.status = employee.status || "Inactive"; // Ensure status is displayed
    });

    // Render the view with the employees
    res.render("manager/view_employee", { employees });
  } catch (err) {
    console.error(err);
    res.redirect("/manager/employee/view?error=Failed to load employees.");
  }
});
// View More Employee Details Route
router.get(
  "/employee/viewMore/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    const { id } = req.params;

    try {
      // Query to fetch detailed employee information
      const [employeeDetails] = await pool.query(
        `
        SELECT * FROM employees WHERE id = ?
        `,
        [id]
      );

      if (employeeDetails.length > 0) {
        const employee = employeeDetails[0];
        res.render("manager/view_more_employee", { employee }); // Render the detailed page
      } else {
        res.redirect("/manager/employee/view?error=Employee not found.");
      }
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/employee/view?error=Failed to load employee details."
      );
    }
  }
);

// View More terminated Employee Details Route
router.get(
  "/employee/viewMore/terminated/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    const { id } = req.params;

    try {
      // Query to fetch detailed employee information
      const [employeeDetails] = await pool.query(
        `
        SELECT * FROM employees WHERE id = ?
        `,
        [id]
      );

      if (employeeDetails.length > 0) {
        const employee = employeeDetails[0];
        res.render("manager/view_more_terminated_employee", { employee }); // Render the detailed page
      } else {
        res.redirect("/manager/employee/view?error=Employee not found.");
      }
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/employee/view?error=Failed to load employee details."
      );
    }
  }
);

// Route to terminate an employee
router.post(
  "/employee/terminate/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    const { id } = req.params;

    try {
      // Update the status of the employee to 'Terminated'
      await pool.query(
        `UPDATE employees SET status = 'Terminated' WHERE id = ?`,
        [id]
      );

      // Redirect to the employee view page with success message
      res.redirect(
        "/manager/employee/view?success=Employee terminated successfully."
      );
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/employee/view?error=Failed to terminate employee."
      );
    }
  }
);

// Route to view terminated employees
router.get(
  "/employee/terminated",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      // Fetch employees with the status 'Terminated'
      const [terminatedEmployees] = await pool.query(`
      SELECT * FROM employees WHERE status = 'Terminated'
    `);

      // Format the data for terminated employees
      terminatedEmployees.forEach((employee) => {
        employee.contact_info = employee.contact_info || "Not Provided";
        employee.salary = employee.salary || "Not Set";
        employee.status = employee.status || "Terminated";
      });

      // Render the terminated employees page, passing 'employees' to EJS
      res.render("manager/view_terminated_employee", {
        employees: terminatedEmployees,
      });
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/employee/view?error=Failed to load terminated employees."
      );
    }
  }
);

router.get("/leave/history", isAuthenticated("manager"), async (req, res) => {
  try {
    // Query to get employees with leave information
    const [employees] = await pool.execute(`
      SELECT 
        id,
        fullname AS employee_name,
        role AS employee_role,
        taken_leave_days,
        leave_month,
        status
      FROM 
        employees
      WHERE 
        taken_leave_days > 0
        AND leave_month IS NOT NULL
      ORDER BY 
        leave_month DESC, employee_name ASC
    `);

    // Format the data for display
    const leaveHistory = employees.map((employee) => ({
      employee_name: employee.employee_name,
      employee_role: employee.employee_role,
      taken_leave_days: `${employee.taken_leave_days} day${
        employee.taken_leave_days !== 1 ? "s" : ""
      }`,
      leave_month: employee.leave_month,
      status: employee.status,
    }));

    res.render("manager/leave_history", {
      title: "Leave History",
      leaveHistory: leaveHistory,
      success: req.query.success,
      error: req.query.error,
    });
  } catch (err) {
    console.error("Error fetching leave history:", err);
    res.redirect("/manager/employee/menu?error=Failed to load leave history");
  }
});

// Route to toggle employee status
router.post(
  "/employee/toggle-status/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    const employeeId = req.params.id;
    const { leaveDays, leaveMonth } = req.body;

    try {
      // Fetch the current status and leave days of the employee
      const [employee] = await pool.execute(
        "SELECT status, leave_days FROM employees WHERE id = ?",
        [employeeId]
      );

      // Check if the employee exists
      if (employee.length === 0) {
        return res.redirect("/manager/employee/view?error=Employee not found.");
      }

      const currentStatus = employee[0].status;
      const currentLeaveDays = employee[0].leave_days || 0;
      const newStatus = currentStatus === "Active" ? "Inactive" : "Active";

      // Prepare update parameters
      let updateQuery = "UPDATE employees SET status = ?";
      const updateParams = [newStatus];

      // If deactivating, process leave days
      if (currentStatus === "Active" && newStatus === "Inactive") {
        if (!leaveDays || !leaveMonth) {
          return res.redirect(
            "/manager/employee/view?error=Leave days and month are required when deactivating."
          );
        }

        const parsedLeaveDays = parseInt(leaveDays);
        if (isNaN(parsedLeaveDays) || parsedLeaveDays < 0) {
          return res.redirect(
            "/manager/employee/view?error=Invalid leave days value."
          );
        }

        if (parsedLeaveDays > currentLeaveDays) {
          return res.redirect(
            `/manager/employee/view?error=Taken leave days (${parsedLeaveDays}) cannot exceed available leave days (${currentLeaveDays}).`
          );
        }

        const newLeaveDays = currentLeaveDays - parsedLeaveDays;

        updateQuery +=
          ", leave_days = ?, taken_leave_days = ?, leave_month = ?";
        updateParams.push(newLeaveDays, parsedLeaveDays, leaveMonth);
      }

      updateParams.push(employeeId);

      // Execute the update
      await pool.execute(`${updateQuery} WHERE id = ?`, updateParams);

      res.redirect("/manager/employee/view?success=Employee status updated.");
    } catch (err) {
      console.error("Error updating status:", err);
      res.redirect(
        "/manager/employee/view?error=Failed to update employee status."
      );
    }
  }
);
// Route for updating employee
router.post(
  "/employee/update/:id",
  isAuthenticated("manager"),
  upload.single("id_card"),
  (req, res, next) => {
    // Handle Multer file upload errors
    if (req.fileValidationError) {
      return res.status(400).send(req.fileValidationError);
    }
    next();
  },
  async (req, res) => {
    try {
      const { id } = req.params;
      const {
        fullname,
        age,
        role,
        contact_info,
        salary,
        status,
        gender,
        co_signer_fullname,
        cosigner_contactinfo,
        employee_type,
      } = req.body;

      // Handle file upload if a new file is provided
      const id_card = req.file ? req.file.path : null;

      // Check if employee exists
      const [existingEmployee] = await pool.query(
        "SELECT * FROM employees WHERE id = ?",
        [id]
      );
      if (existingEmployee.length === 0) {
        return res.redirect("/manager/employee/view?error=Employee not found.");
      }

      // Sanitize fields by replacing empty strings or undefined with null
      const fields = {
        fullname: fullname || null,
        age: age || null,
        role: role || null,
        contact_info: contact_info || null,
        salary: salary || null,
        status: status || null,
        gender: gender || null,
        co_signer_fullname: co_signer_fullname || null,
        cosigner_contactinfo: cosigner_contactinfo || null,
        employee_type: employee_type || null,
      };

      // Build the query dynamically
      let query = `UPDATE employees SET fullname = ?, age = ?, role = ?, contact_info = ?, salary = ?, status = ?, gender = ?, co_signer_fullname = ?, cosigner_contactinfo = ?, employment_type = ?`;
      let values = [
        fields.fullname,
        fields.age,
        fields.role,
        fields.contact_info,
        fields.salary,
        fields.status,
        fields.gender,
        fields.co_signer_fullname,
        fields.cosigner_contactinfo,
        fields.employee_type,
      ];

      // Add id_card to the query if provided
      if (id_card) {
        query += `, id_card = ?`;
        values.push(id_card);
      }

      query += ` WHERE id = ?`;
      values.push(id);

      // Execute the update query
      await pool.execute(query, values);

      // Redirect to the employee view page with a success message
      res.redirect(
        "/manager/employee/view?success=Employee updated successfully!"
      );
    } catch (err) {
      console.error(err);
      res.redirect("/manager/employee/view?error=Failed to update employee.");
    }
  }
);

// Route to load employee update form (GET)
router.get(
  "/employee/update/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      const { id } = req.params;

      // Fetch the employee data from the database
      const [employees] = await pool.execute(
        "SELECT * FROM employees WHERE id = ?",
        [id]
      );

      if (employees.length === 0) {
        return res.redirect("/manager/employee/view?error=Employee not found.");
      }

      const employee = employees[0];

      // Render the update form, passing employee data to the template
      res.render("manager/update_employee", { employee: employee });
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/employee/view?error=Failed to load employee for update."
      );
    }
  }
);

//create room   route
router.post("/rooms/create", isAuthenticated("manager"), async (req, res) => {
  const {
    room_type,
    price_per_kare,
    total_kare,
    start_room_number,
    end_room_number,
    resident_type,
  } = req.body;

  if (
    !room_type ||
    !price_per_kare ||
    !total_kare ||
    !start_room_number ||
    !end_room_number
  ) {
    return res.render("manager/create_rooms", {
      error: "All fields are required!",
    });
  }

  const price = parseFloat(price_per_kare);
  const kare = parseFloat(total_kare);

  if (isNaN(price) || isNaN(kare) || price <= 0 || kare <= 0) {
    return res.redirect(
      "/manager/rooms/create?error=Invalid price per kare or total kare!"
    );
  }

  try {
    const roomsToCreate = generateRoomNumbers(
      start_room_number,
      end_room_number
    );

    if (roomsToCreate.length === 0) {
      return res.redirect(
        "/manager/rooms/create?error=Invalid room number range!!"
      );
    }

    // Check if the room numbers already exist in the database
    const roomChecks = roomsToCreate
      .map((room) => `room_number LIKE ?`)
      .join(" OR ");
    const values = roomsToCreate.map((room) => room);

    const [existingRooms] = await pool.execute(
      `SELECT room_number FROM rooms WHERE ${roomChecks}`,
      values
    );

    if (existingRooms.length > 0) {
      // Handle case where rooms already exist
      return res.redirect(
        "/manager/rooms/create?error=One or more room numbers already exist!"
      );
    }

    // Proceed with creating new rooms if none exist

    // If no room numbers exist, proceed to create the rooms
    for (const room_number of roomsToCreate) {
      const rent = price * kare;

      await pool.execute(
        `INSERT INTO rooms (room_number, type, price_per_kare, total_kare, rent, status, resident_type)
         VALUES (?, ?, ?, ?, ?, ?, ?);`,
        [
          room_number,
          room_type,
          price,
          kare,
          rent,
          "Vacant",
          room_type === "Resident" ? resident_type : null,
        ]
      );
    }

    res.redirect("/manager/rooms/create?success=Rooms created successfully!");
  } catch (err) {
    console.error(err);
    res.render("manager/create_rooms", {
      error: "Failed to create rooms.",
    });
  }
});

function generateRoomNumbers(start, end) {
  const rooms = [];
  const startMatch = start.match(/^(\d+)([A-Za-z]?)$/);
  const endMatch = end.match(/^(\d+)([A-Za-z]?)$/);

  if (!startMatch || !endMatch) return rooms;

  const startNum = parseInt(startMatch[1], 10);
  const endNum = parseInt(endMatch[1], 10);
  const suffix = startMatch[2] || ""; // Handles cases with or without suffixes

  if (isNaN(startNum) || isNaN(endNum) || startNum > endNum) return rooms;

  for (let i = startNum; i <= endNum; i++) {
    rooms.push(`${i}${suffix}`);
  }

  return rooms;
}

// View Rooms with Occupancy Status
router.get("/rooms/view", isAuthenticated("manager"), async (req, res) => {
  try {
    // Fetch the rooms from the database with the most recent data
    const [rooms] = await pool.execute("SELECT * FROM rooms");

    // Render the rooms page with the fetched data
    res.render("manager/view_rooms", { rooms });
  } catch (err) {
    console.error("Error fetching rooms:", err);
    res.redirect("manager/view_rooms?error=Failed to fetch room details.");
  }
});

// Route to update room status
// Route to update room status
router.post(
  "/rooms/update-status/:room_number",
  isAuthenticated("manager"),
  async (req, res) => {
    const roomNumber = req.params.room_number;
    const currentStatus = req.body.currentStatus;

    // Toggle status between 'Occupied' and 'Vacant'
    const newStatus =
      currentStatus.toLowerCase() === "occupied" ? "Vacant" : "Occupied";

    try {
      // Update room status in the database
      await pool.execute("UPDATE rooms SET status = ? WHERE room_number = ?", [
        newStatus,
        roomNumber,
      ]);

      // Fetch the updated list of rooms
      const [rooms] = await pool.execute("SELECT * FROM rooms");

      // Render updated rooms list
      res.render("manager/view_rooms", { rooms });
    } catch (err) {
      console.error("Error updating room status:", err);
      res.redirect("manager/view_rooms?error=Failed to update room status.");
    }
  }
);

// Route to Update Price Per Kare and Recalculate Rent
router.post(
  "/room/update-price/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    const roomId = req.params.id;
    const { new_price_per_kare, manager_name } = req.body;

    try {
      // Fetch current price and total kare
      const [room] = await pool.query(
        `SELECT price_per_kare, total_kare FROM rooms WHERE id = ?`,
        [roomId]
      );
      if (room.length === 0) {
        return res.redirect(`/manager/room/view?error=Room not found`);
      }

      const old_price = room[0].price_per_kare;
      const total_kare = room[0].total_kare;

      // Log price change in history
      await pool.query(
        `
      INSERT INTO price_per_kare_history (room_id, old_price, new_price, changed_by)
      VALUES (?, ?, ?, ?)
    `,
        [roomId, old_price, new_price_per_kare, manager_name]
      );

      // Calculate new rent
      const new_rent = new_price_per_kare * total_kare;

      // Update room with new price and rent
      await pool.query(
        `
      UPDATE rooms SET price_per_kare = ?, rent = ? WHERE id = ?
    `,
        [new_price_per_kare, new_rent, roomId]
      );

      res.redirect("/manager/room/view?success=Price updated successfully");
    } catch (err) {
      console.error(err);
      res.redirect(`/manager/room/view?error=Failed to update price`);
    }
  }
);
//route for viewing pricr history
router.get(
  "/rooms/price-history",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      // Fetch historical price data with room information (including resident_type)
      const [priceHistory] = await pool.query(`
      SELECT ph.*, r.room_number
      FROM price_per_kare_history ph
      JOIN rooms r ON ph.room_id = r.id
      ORDER BY ph.changed_at DESC
    `);

      // Log the data to verify it's coming through
      /*   console.log(priceHistory); */

      res.render("manager/price_history", { priceHistory });
    } catch (err) {
      console.error(err);
      res.redirect("/manager/rooms/menu?error=Failed to load price history.");
    }
  }
);

// POST Route - Handle Price Update
// Update Price Per Kare for All Rooms
router.post(
  "/rooms/update-price",
  isAuthenticated("manager"),
  async (req, res) => {
    const { new_price_per_kare } = req.body;

    if (!new_price_per_kare || isNaN(parseFloat(new_price_per_kare))) {
      return res.redirect("/manager/rooms/view?error=Invalid price input.");
    }

    try {
      // Fetch all rooms to get old prices and total_kare
      const [rooms] = await pool.query(
        "SELECT id, price_per_kare, total_kare FROM rooms"
      );

      // Loop through rooms to update and log changes
      for (const room of rooms) {
        const old_price = room.price_per_kare;
        const total_kare = room.total_kare;
        const new_rent = parseFloat(new_price_per_kare) * total_kare;

        // Update room with new price and recalculated rent
        await pool.query(
          "UPDATE rooms SET price_per_kare = ?, rent = ? WHERE id = ?",
          [new_price_per_kare, new_rent, room.id]
        );

        // Log the price change in history table
        await pool.query(
          `INSERT INTO price_per_kare_history (room_id, old_price, new_price, changed_by)
         VALUES (?, ?, ?, ?)`,
          [room.id, old_price, new_price_per_kare, "Manager"]
        );
      }

      res.redirect(
        "/manager/rooms/view?success=Price per kare updated for all rooms!"
      );
    } catch (err) {
      console.error(err);
      res.redirect("/manager/rooms/view?error=Failed to update price.");
    }
  }
);

// Delete Room Route with related history deletion
router.post("/delete/:id", async (req, res) => {
  const roomId = req.params.id;

  try {
    // First, delete related records from price_per_kare_history
    await db.query("DELETE FROM price_per_kare_history WHERE room_id = ?", [
      roomId,
    ]);

    // Then, delete the room
    await db.query("DELETE FROM rooms WHERE id = ?", [roomId]);

    res.redirect("/manager/rooms/view");
  } catch (err) {
    console.error("Error deleting room:", err);
    res.status(500).send("Error deleting room");
  }
});

router.get("/payments/menu", isAuthenticated("manager"), (req, res) => {
  res.render("manager/payments_menu");
});
//route to mannage payment
router.get("/tenants/payment", isAuthenticated("manager"), async (req, res) => {
  try {
    // Query to fetch tenants with their payments
    const [tenants] = await pool.query(`
      SELECT tenants.id, tenants.full_name, tenants.room_number, 
             payments.id AS payment_id, payments.amount, payments.status, 
             CONCAT(payments.payment_year, '-', payments.payment_month) AS payment_period,
             payments.receipt,
             payments.created_at AS payment_created_at
      FROM tenants
      LEFT JOIN payments ON tenants.id = payments.tenant_id
      WHERE tenants.tenant_status != 'Terminated'
      ORDER BY tenants.full_name, payments.created_at DESC;
    `);

    // Group payments by tenant and format dates
    const tenantData = tenants.reduce((acc, tenant) => {
      const {
        id,
        full_name,
        room_number,
        payment_id,
        amount,
        status,
        payment_period,
        receipt,
        payment_created_at,
      } = tenant;

      if (!acc[id]) {
        acc[id] = {
          id,
          full_name,
          room_number,
          payments: [],
        };
      }

      if (payment_id) {
        acc[id].payments.push({
          id: payment_id,
          amount,
          status,
          payment_period,
          receipt,
          created_at: payment_created_at,
          // Add formatted date here
          formatted_created_at: payment_created_at
            ? new Date(payment_created_at).toLocaleString("en-US", {
                year: "numeric",
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              })
            : "N/A",
        });
      }
      return acc;
    }, {});

    res.render("manager/tenants_payment", {
      tenants: Object.values(tenantData),
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error." });
  }
});
router.get("/payment/count", async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT COUNT(*) AS count FROM payments WHERE status = 'Pending'"
    );
    res.json({ count: rows[0].count });
  } catch (error) {
    console.error("Error fetching maintenance count:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

//route to update payment status
router.post(
  "/tenants/payment/update",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      const { paymentId, status, manager_note } = req.body;

      // Ensure valid status values
      if (!["approved", "declined"].includes(status)) {
        return res.status(400).json({ message: "Invalid status value." });
      }
      let updateQuery = "UPDATE payments SET status = ?";
      let updateParams = [status];
      if (status === "approved") {
        updateQuery = "UPDATE payments SET status = ?, approved_at = NOW()";
        updateParams = [status];
      }

      if (status === "declined" && manager_note) {
        updateQuery += ", manager_note = ?";
        updateParams.push(manager_note); // Add manager_note at the END
      } else {
        updateQuery += ", manager_note = NULL"; // Ensure manager_note is always handled
      }

      updateQuery += " WHERE id = ?";
      updateParams.push(paymentId); // paymentId should always be the last parameter

      const [result] = await pool.query(updateQuery, updateParams);

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Payment not found." });
      }

      res.json({ message: `Payment status updated to ${status}.` });
    } catch (error) {
      console.error("Error updating payment status:", error);
      res.status(500).json({ message: "Server error." });
    }
  }
);

// Route to show overdue tenants
router.get("/overdue_tenants", isAuthenticated("manager"), async (req, res) => {
  try {
    const [overdueTenants] = await pool.query(
      `SELECT t.full_name, t.email, t.room_number, p.payment_month, p.payment_year, p.amount, p.status 
       FROM payments p 
       JOIN tenants t ON p.tenant_id = t.id
       WHERE p.status != "declined" 
       AND (CURDATE() > p.grace_period_end OR p.grace_period_end IS NULL)
       AND t.tenant_status != "Terminated"`
    );

    if (overdueTenants.length === 0) {
      res.render("manager/overdue_tenants", {
        overdueTenants,
        message: "No overdue tenants found.",
      });
    } else {
      res.render("manager/overdue_tenants", { overdueTenants });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error fetching overdue tenants." });
  }
});

// route to count overdue tenants
router.get(
  "/overdue_tenants/count",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      const [result] = await pool.query(
        `SELECT COUNT(*) AS count
       FROM payments 
       WHERE status != "approved" AND CURDATE() > grace_period_end`
      );

      res.json({ count: result[0].count });
    } catch (error) {
      console.error("Error fetching overdue tenants count:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  }
);

//route to display manage rooms menu
router.get("/rooms/menu", isAuthenticated("manager"), (req, res) => {
  res.render("manager/rooms_menu");
});
// Route to display the "Create Room" form
router.get("/rooms/create", isAuthenticated("manager"), (req, res) => {
  res.render("manager/create_rooms", { error: null }); // Renders the create_room.ejs template
});

// Route for viewing update form
router.get(
  "/tenant/update/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      const { id } = req.params;

      // Fetch the tenant data including tenant_type and business details
      const [tenants] = await pool.execute(
        `SELECT tenants.*, businesses.business_name, businesses.business_type, businesses.license_number, businesses.license_image
         FROM tenants
         LEFT JOIN businesses ON tenants.id = businesses.tenant_id
         WHERE tenants.id = ?`,
        [id]
      );

      if (tenants.length === 0) {
        return res.redirect("/manager/tenants/view?error=Tenant not found.");
      }

      const tenant = tenants[0];

      // Render the update form, passing the tenant data including tenant_type
      res.render("manager/update_tenant", { tenant });
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/tenants/view?error=Failed to load tenant for update."
      );
    }
  }
);

//route to update the tenant
router.post(
  "/tenants/update/:id",
  isAuthenticated("manager"),
  upload.fields([
    { name: "id_card", maxCount: 1 },
    { name: "license_image", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const { id } = req.params;

      // Check if tenant exists
      const [existingTenantRows] = await pool.query(
        "SELECT * FROM tenants WHERE id = ?",
        [id]
      );

      if (existingTenantRows.length === 0) {
        return res.redirect("/manager/tenants/view?error=Tenant not found.");
      }

      const existingTenant = existingTenantRows[0];

      // Assign defaults if fields are missing
      const full_name = req.body.full_name || existingTenant.full_name;
      const email = req.body.email || existingTenant.email;
      const phone = req.body.phone || existingTenant.phone;
      const room_number = req.body.room_number || existingTenant.room_number;
      const lease_start = req.body.lease_start || existingTenant.lease_start;
      const lease_end = req.body.lease_end || existingTenant.lease_end;
      const business_name =
        req.body.business_name || existingTenant.business_name || null;
      const business_type =
        req.body.business_type || existingTenant.business_type || null;
      const license_number =
        req.body.license_number || existingTenant.license_number || null;

      // Check lease dates validity
      if (new Date(lease_end) < new Date(lease_start)) {
        return res.redirect(
          "/manager/tenants/view?error=Lease end date cannot be before lease start date."
        );
      }

      // Handle uploaded files
      const id_card =
        req.files?.["id_card"]?.[0]?.path || existingTenant.id_card || null;
      const license_image =
        req.files?.["license_image"]?.[0]?.path ||
        existingTenant.license_image ||
        null;

      // If room number changed, update room statuses
      if (existingTenant.room_number !== room_number) {
        // Validate new room status
        const [roomResult] = await pool.execute(
          "SELECT type, status FROM rooms WHERE room_number = ?",
          [room_number]
        );

        if (roomResult.length === 0) {
          return res.redirect(
            "/manager/tenants/view?error=Room does not exist."
          );
        }

        const roomType = roomResult[0].type;

        // Check if room type matches tenant type
        if (
          (existingTenant.tenant_type === "Residential" &&
            roomType === "Business") ||
          (existingTenant.tenant_type === "Business" &&
            roomType === "Residential")
        ) {
          return res.redirect(
            "/manager/tenants/view?error=Resident type does not match room type!"
          );
        }

        if (roomResult[0].status !== "vacant") {
          return res.redirect(
            "/manager/tenants/view?error=Room is already occupied!"
          );
        }

        // Update tenant's room_number FIRST
        await pool.execute("UPDATE tenants SET room_number = ? WHERE id = ?", [
          room_number,
          id,
        ]);

        // Mark the old room as Vacant
        if (existingTenant.room_number) {
          await pool.execute(
            "UPDATE rooms SET status = 'vacant' WHERE room_number = ?",
            [existingTenant.room_number]
          );
        } else {
          console.log(
            "Room number has not changed. Skipping room status update."
          );
        }
        // Mark the new room as Occupied
        await pool.execute(
          "UPDATE rooms SET status = 'Occupied' WHERE room_number = ?",
          [room_number]
        );
      }

      // Update tenants table
      await pool.execute(
        `UPDATE tenants 
        SET full_name = ?, email = ?, phone = ?, room_number=?, lease_start = ?, lease_end = ?, id_card = ? 
        WHERE id = ?`,
        [
          full_name,
          email,
          phone,
          room_number,
          lease_start,
          lease_end,
          id_card,
          id,
        ]
      );

      // Update business details only if tenant is a business
      if (
        existingTenant.tenant_type === "Business" &&
        business_name &&
        business_type &&
        license_number
      ) {
        await pool.execute(
          `UPDATE businesses 
          SET business_name = ?, business_type = ?, license_number = ?, license_image = COALESCE(?, license_image) 
          WHERE tenant_id = ?`,
          [business_name, business_type, license_number, license_image, id]
        );
      }

      return res.redirect(
        "/manager/tenants/view?success=Tenant updated successfully!"
      );
    } catch (err) {
      console.error("Error updating tenant:", err);
      return res.redirect(
        "/manager/tenants/view?error=Failed to update tenant."
      );
    }
  }
);

//route for deleting tenant
router.get(
  "/tenants/delete/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      const { id } = req.params;

      // Fetch the tenant's email and assigned room number
      const [tenant] = await pool.execute(
        "SELECT email, room_number FROM tenants WHERE id = ?",
        [id]
      );

      if (tenant.length > 0) {
        const tenantEmail = tenant[0].email;
        const roomNumber = tenant[0].room_number;

        // Update room status to 'Vacant' before deleting the tenant
        if (roomNumber) {
          await pool.execute(
            "UPDATE rooms SET status = 'Vacant' WHERE room_number = ?",
            [roomNumber]
          );
        }

        // Delete the corresponding user from the users table
        await pool.execute(
          "UPDATE users SET email = NULL, password = NULL, username = NULL WHERE email",
          [tenantEmail]
        );

        // Now update the tenant status to terminated
        await pool.execute(
          "UPDATE tenants SET tenant_status = 'Terminated' WHERE id = ?",
          [id]
        );

        return res.redirect(
          "/manager/tenants/view?success=Tenant deleted successfully!"
        );
      }

      return res.redirect("/manager/tenants/view?error=Tenant not found.");
    } catch (err) {
      console.error("Error deleting tenant:", err);
      return res.redirect(
        "/manager/tenants/view?error=Failed to delete tenant."
      );
    }
  }
);
//create tenant route

router.post(
  "/tenant/create",
  upload.fields([
    { name: "id_card", maxCount: 1 },
    { name: "license_image", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const {
        username,
        password,
        name,
        email,
        phone,
        room_number,
        lease_start,
        lease_end,
        business_name,
        business_type,
        license_number,
      } = req.body;

      const id_card = req.files?.["id_card"]?.[0]?.path || null;
      const license_image = req.files?.["license_image"]?.[0]?.path || null;
      const tenant_type = business_name ? "Business" : "Residential";

      if (
        !username ||
        !password ||
        !name ||
        !email ||
        !room_number ||
        !lease_start ||
        !lease_end ||
        !tenant_type
      ) {
        return res.redirect(
          "/manager/tenants/create?error=All fields are required!"
        );
      }

      // Ensure Lease End Date is greater than Lease Start Date
      if (new Date(lease_end) <= new Date(lease_start)) {
        return res.redirect(
          "/manager/tenants/create?error=Lease end date must be after lease start date!"
        );
      }

      // Validate room existence and check if the room is already occupied BEFORE user creation
      const [roomResult] = await pool.execute(
        `SELECT room_number, type FROM rooms WHERE room_number = ? AND status != 'Occupied'`,
        [room_number]
      );

      if (roomResult.length === 0) {
        return res.redirect(
          "/manager/tenants/create?error=Room is already occupied or does not exist!"
        );
      }

      // Check for room type mismatch
      const roomType = roomResult[0].type; // Get the room type

      if (
        (tenant_type === "Residential" && roomType === "Business") ||
        (tenant_type === "Business" && roomType === "Residential")
      ) {
        return res.redirect(
          "/manager/tenants/create?error=Resident type does not match room type!"
        );
      }

      // Hash password before saving
      const hashedPassword = await bcrypt.hash(password, 10);

      // Insert into users table
      const [userResult] = await pool.execute(
        `INSERT INTO users (username, password, role, email) VALUES (?, ?, ?, ?)`,
        [username, hashedPassword, "tenant", email]
      );

      // Insert into tenants table
      const [tenantResult] = await pool.execute(
        `INSERT INTO tenants (user_id, full_name, email, phone, id_card, room_number, lease_start, lease_end, tenant_type) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          userResult.insertId,
          name,
          email,
          phone,
          id_card,
          room_number,
          lease_start,
          lease_end,
          tenant_type,
        ]
      );

      // Update room status to 'Occupied'
      await pool.execute(
        `UPDATE rooms SET status = 'Occupied' WHERE room_number = ?`,
        [room_number]
      );

      // If Business Tenant, insert business details
      if (tenant_type === "Business") {
        if (!business_name || !business_type || !license_number) {
          return res.redirect(
            "/manager/tenants/create?error=Business details are required!"
          );
        }

        await pool.execute(
          `INSERT INTO businesses (tenant_id, business_name, business_type, license_number, license_image, start_date) 
          VALUES (?, ?, ?, ?, ?, ?)`,
          [
            tenantResult.insertId,
            business_name,
            business_type,
            license_number,
            license_image,
            lease_start,
          ]
        );
      }

      return res.redirect(
        "/manager/tenants/create?success=Tenant created successfully!"
      );
    } catch (err) {
      // Handle username and/or email conflicts
      if (err.code === "ER_DUP_ENTRY") {
        console.error("Duplicate entry error:", err);
        return res.redirect(
          "/manager/tenants/create?error=Username or email already exists!"
        );
      }

      console.error("Error creating tenant:", err);
      return res.status(500).json({ error: "Failed to create tenant." });
    }
  }
);

//route view tenant

router.get("/tenants/view", isAuthenticated("manager"), async (req, res) => {
  try {
    // Fetch tenants from the database, including room and business details
    const [tenants] = await pool.query(`
  SELECT
    tenants.*,
    rooms.room_number,  
    CASE
      WHEN businesses.business_name IS NOT NULL THEN 'Business'
      ELSE 'Residential'
    END AS tenant_type
  FROM tenants 

  LEFT JOIN rooms ON tenants.room_number = rooms.room_number  -- ✅ Use room_number instead of room_id
  LEFT JOIN businesses ON tenants.id = businesses.tenant_id 
  WHERE tenant_status != 'Terminated' AND lease_end >= CURDATE()
`);

    // Format lease start and end dates using moment
    tenants.forEach((tenant) => {
      tenant.lease_start_formatted = moment(tenant.lease_start).format(
        "YYYY-MM-DD"
      );
      tenant.lease_end_formatted = moment(tenant.lease_end).format(
        "YYYY-MM-DD"
      );
    });

    // Render the view with the tenants
    res.render("manager/view_tenants", { tenants });
  } catch (err) {
    console.error(err);
    res.redirect("/manager/tenants/view?error=Failed to load tenants.");
  }
});

//route to view more tenats

router.get(
  "/tenant/viewMore/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    const { id } = req.params;
    try {
      const [tenantDetails] = await pool.query(
        `SELECT
          tenants.*,
          rooms.room_number,  
          businesses.business_name,
          businesses.business_type,
          businesses.license_number,
          businesses.license_image
        FROM tenants 
        LEFT JOIN rooms ON tenants.room_number = rooms.room_number  -- ✅ Use room_number instead of room_id
        LEFT JOIN businesses ON tenants.id = businesses.tenant_id
        WHERE tenants.id = ? `,
        [id]
      );

      if (tenantDetails.length > 0) {
        const tenant = tenantDetails[0];

        // Format lease dates correctly
        tenant.lease_start_formatted = moment(tenant.lease_start).format(
          "YYYY-MM-DD"
        );
        tenant.lease_end_formatted = moment(tenant.lease_end).format(
          "YYYY-MM-DD"
        );

        res.render("manager/view_more_tenant", { tenant });
      } else {
        res.redirect("/manager/tenants/view?error=Tenant not found.");
      }
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/tenants/view?error=Failed to load tenant details."
      );
    }
  }
);
//view terminated tenants
router.get(
  "/tenants/view/terminated",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      // Fetch tenants from the database, including room and business details
      const [tenants] = await pool.query(`
  SELECT
    tenants.*,
    rooms.room_number,  
    CASE
      WHEN businesses.business_name IS NOT NULL THEN 'Business'
      ELSE 'Residential'
    END AS tenant_type
  FROM tenants 

  LEFT JOIN rooms ON tenants.room_number = rooms.room_number  -- ✅ Use room_number instead of room_id
  LEFT JOIN businesses ON tenants.id = businesses.tenant_id 
  WHERE tenant_status != 'Active'
`);

      // Format lease start and end dates using moment
      tenants.forEach((tenant) => {
        tenant.lease_start_formatted = moment(tenant.lease_start).format(
          "YYYY-MM-DD"
        );
        tenant.lease_end_formatted = moment(tenant.lease_end).format(
          "YYYY-MM-DD"
        );
      });

      // Render the view with the tenants
      res.render("manager/view_terminated_tenants", { tenants });
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/tenants/view/terminated?error=Failed to load tenants."
      );
    }
  }
);

//route to view more tenats

router.get(
  "/tenant/viewMore/terminated/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    const { id } = req.params;
    try {
      const [tenantDetails] = await pool.query(
        `SELECT
          tenants.*,
          rooms.room_number,  
          businesses.business_name,
          businesses.business_type,
          businesses.license_number,
          businesses.license_image
        FROM tenants 
        LEFT JOIN rooms ON tenants.room_number = rooms.room_number  -- ✅ Use room_number instead of room_id
        LEFT JOIN businesses ON tenants.id = businesses.tenant_id
        WHERE tenants.id = ? `,
        [id]
      );

      if (tenantDetails.length > 0) {
        const tenant = tenantDetails[0];

        // Format lease dates correctly
        tenant.lease_start_formatted = moment(tenant.lease_start).format(
          "YYYY-MM-DD"
        );
        tenant.lease_end_formatted = moment(tenant.lease_end).format(
          "YYYY-MM-DD"
        );

        res.render("manager/view_more_terminated_tenant", { tenant });
      } else {
        res.redirect(
          "/manager/tenants/view/terminated?error=Tenant not found."
        );
      }
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/tenants/view/terminated?error=Failed to load tenant details."
      );
    }
  }
);

//tenats with expired lease

router.get(
  "/terminated-lease",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      // Fetch tenants from the database, including room and business details
      const [tenants] = await pool.query(`
  SELECT
    tenants.*,
    rooms.room_number,  
    CASE
      WHEN businesses.business_name IS NOT NULL THEN 'Business'
      ELSE 'Residential'
    END AS tenant_type
  FROM tenants 

  LEFT JOIN rooms ON tenants.room_number = rooms.room_number  -- ✅ Use room_number instead of room_id
  LEFT JOIN businesses ON tenants.id = businesses.tenant_id 
  WHERE tenant_status != 'Terminated'  AND lease_end < CURDATE()
`);

      // Format lease start and end dates using moment
      tenants.forEach((tenant) => {
        tenant.lease_start_formatted = moment(tenant.lease_start).format(
          "YYYY-MM-DD"
        );
        tenant.lease_end_formatted = moment(tenant.lease_end).format(
          "YYYY-MM-DD"
        );
      });

      // Render the view with the tenants
      res.render("manager/view_terminated_lease", { tenants });
    } catch (err) {
      console.error(err);
      res.redirect("/manager/terminated-lease?error=Failed to load tenants.");
    }
  }
);

//view more expired lease

router.get("/viewMore/:id", isAuthenticated("manager"), async (req, res) => {
  const { id } = req.params;
  try {
    const [tenantDetails] = await pool.query(
      `SELECT
          tenants.*,
          rooms.room_number,  
          businesses.business_name,
          businesses.business_type,
          businesses.license_number,
          businesses.license_image
        FROM tenants 
        LEFT JOIN rooms ON tenants.room_number = rooms.room_number  -- ✅ Use room_number instead of room_id
        LEFT JOIN businesses ON tenants.id = businesses.tenant_id
        WHERE tenants.id = ? `,
      [id]
    );

    if (tenantDetails.length > 0) {
      const tenant = tenantDetails[0];

      // Format lease dates correctly
      tenant.lease_start_formatted = moment(tenant.lease_start).format(
        "YYYY-MM-DD"
      );
      tenant.lease_end_formatted = moment(tenant.lease_end).format(
        "YYYY-MM-DD"
      );

      res.render("manager/view_more_expired_lease", { tenant });
    } else {
      res.redirect("/manager/terminated-lease?error=Tenant not found.");
    }
  } catch (err) {
    console.error(err);
    res.redirect(
      "/manager/terminated-lease?error=Failed to load tenant details."
    );
  }
});

// Route for viewing update form
router.get(
  "/expired-update/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      const { id } = req.params;

      // Fetch the tenant data including tenant_type and business details
      const [tenants] = await pool.execute(
        `SELECT tenants.*, businesses.business_name, businesses.business_type, businesses.license_number, businesses.license_image
         FROM tenants
         LEFT JOIN businesses ON tenants.id = businesses.tenant_id
         WHERE tenants.id = ?`,
        [id]
      );

      if (tenants.length === 0) {
        return res.redirect(
          "/manager/terminated-lease?error=Tenant not found."
        );
      }

      const tenant = tenants[0];

      // Render the update form, passing the tenant data including tenant_type
      res.render("manager/update_expire_lease_tenants", { tenant });
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/terminated-lease?error=Failed to load tenant for update."
      );
    }
  }
);

//route to update expired  the tenant
router.post(
  "/expired-tenats-update/:id",
  isAuthenticated("manager"),
  upload.fields([
    { name: "id_card", maxCount: 1 },
    { name: "license_image", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const { id } = req.params;

      // Check if tenant exists
      const [existingTenantRows] = await pool.query(
        "SELECT * FROM tenants WHERE id = ?",
        [id]
      );

      if (existingTenantRows.length === 0) {
        return res.redirect(
          "/manager/terminated-lease?error=Tenant not found."
        );
      }

      const existingTenant = existingTenantRows[0];

      // Assign defaults if fields are missing
      const full_name = req.body.full_name || existingTenant.full_name;
      const email = req.body.email || existingTenant.email;
      const phone = req.body.phone || existingTenant.phone;
      const room_number = req.body.room_number || existingTenant.room_number;
      const lease_start = req.body.lease_start || existingTenant.lease_start;
      const lease_end = req.body.lease_end || existingTenant.lease_end;
      const business_name =
        req.body.business_name || existingTenant.business_name || null;
      const business_type =
        req.body.business_type || existingTenant.business_type || null;
      const license_number =
        req.body.license_number || existingTenant.license_number || null;

      // Check lease dates validity
      if (new Date(lease_end) < new Date(lease_start)) {
        return res.redirect(
          "/manager/terminated-lease?error=Lease end date cannot be before lease start date."
        );
      }

      // Handle uploaded files
      const id_card =
        req.files?.["id_card"]?.[0]?.path || existingTenant.id_card || null;
      const license_image =
        req.files?.["license_image"]?.[0]?.path ||
        existingTenant.license_image ||
        null;

      // If room number changed, update room statuses
      if (existingTenant.room_number !== room_number) {
        // Validate new room status
        const [roomResult] = await pool.execute(
          "SELECT type, status FROM rooms WHERE room_number = ?",
          [room_number]
        );

        if (roomResult.length === 0) {
          return res.redirect(
            "/manager/terminated-lease?error=Room does not exist."
          );
        }

        const roomType = roomResult[0].type;

        // Check if room type matches tenant type
        if (
          (existingTenant.tenant_type === "Residential" &&
            roomType === "Business") ||
          (existingTenant.tenant_type === "Business" &&
            roomType === "Residential")
        ) {
          return res.redirect(
            "/manager/terminated-lease?error=Resident type does not match room type!"
          );
        }

        if (roomResult[0].status !== "vacant") {
          return res.redirect(
            "/manager/terminated-lease?error=Room is already occupied!"
          );
        }

        // Update tenant's room_number FIRST
        await pool.execute("UPDATE tenants SET room_number = ? WHERE id = ?", [
          room_number,
          id,
        ]);

        // Mark the old room as Vacant
        if (existingTenant.room_number) {
          await pool.execute(
            "UPDATE rooms SET status = 'vacant' WHERE room_number = ?",
            [existingTenant.room_number]
          );
        } else {
          console.log(
            "Room number has not changed. Skipping room status update."
          );
        }
        // Mark the new room as Occupied
        await pool.execute(
          "UPDATE rooms SET status = 'Occupied' WHERE room_number = ?",
          [room_number]
        );
      }

      // Update tenants table
      await pool.execute(
        `UPDATE tenants 
        SET full_name = ?, email = ?, phone = ?, room_number=?, lease_start = ?, lease_end = ?, id_card = ? 
        WHERE id = ?`,
        [
          full_name,
          email,
          phone,
          room_number,
          lease_start,
          lease_end,
          id_card,
          id,
        ]
      );

      // Update business details only if tenant is a business
      if (
        existingTenant.tenant_type === "Business" &&
        business_name &&
        business_type &&
        license_number
      ) {
        await pool.execute(
          `UPDATE businesses 
          SET business_name = ?, business_type = ?, license_number = ?, license_image = COALESCE(?, license_image) 
          WHERE tenant_id = ?`,
          [business_name, business_type, license_number, license_image, id]
        );
      }

      return res.redirect(
        "/manager/terminated-lease?success=Tenant updated successfully!"
      );
    } catch (err) {
      console.error("Error updating tenant:", err);
      return res.redirect(
        "/manager/terminated-lease?error=Failed to update tenant."
      );
    }
  }
);
//route delete expired tenant

//route for deleting tenant
router.get(
  "/expired-delete/:id",
  isAuthenticated("manager"),
  async (req, res) => {
    try {
      const { id } = req.params;

      // Fetch the tenant's email and assigned room number
      const [tenant] = await pool.execute(
        "SELECT email, room_number FROM tenants WHERE id = ?",
        [id]
      );

      if (tenant.length > 0) {
        const tenantEmail = tenant[0].email;
        const roomNumber = tenant[0].room_number;

        // Update room status to 'Vacant' before deleting the tenant
        if (roomNumber) {
          await pool.execute(
            "UPDATE rooms SET status = 'Vacant' WHERE room_number = ?",
            [roomNumber]
          );
        }

        // Delete the corresponding user from the users table
        await pool.execute(
          "UPDATE users SET email = NULL, password = NULL, username = NULL WHERE email",
          [tenantEmail]
        );

        // Now update the tenant status to terminated
        await pool.execute(
          "UPDATE tenants SET tenant_status = 'Terminated' WHERE id = ?",
          [id]
        );

        return res.redirect(
          "/manager/terminated-lease?success=Tenant deleted successfully!"
        );
      }

      return res.redirect("/manager/terminated-lease?error=Tenant not found.");
    } catch (err) {
      console.error("Error deleting tenant:", err);
      return res.redirect(
        "/manager/terminated-lease?error=Failed to delete tenant."
      );
    }
  }
);

// Route to display maintenance requests to the manager
router.get("/manage_maintenance", async (req, res) => {
  try {
    // --- Authentication/Authorization Check ---
    if (!req.session.user || req.session.user.role !== "manager") {
      return res.redirect("/login");
    }

    // --- Fetch Data ---
    // Fetch all maintenance requests
    const [maintenanceRequests] = await pool.query(
      "SELECT * FROM maintenance_requests ORDER BY created_at DESC" // Added ordering
    );

    // Fetch available stock items (quantity > 0)
    const [stockItems] = await pool.query(
      "SELECT id, item_name, item_maintenance_type,quantity FROM stock_items WHERE quantity > 0 ORDER BY item_name ASC"
    );

    // --- Render View ---
    // Check for messages from query parameters (if using that method)
    const errorMessage = req.query.error
      ? decodeURIComponent(req.query.error)
      : "";
    const successMessage = req.query.success
      ? decodeURIComponent(req.query.success)
      : "";

    res.render("manager/manage_maintenance", {
      maintenanceRequests: maintenanceRequests, // Pass fetched requests
      stockItems: stockItems, // Pass fetched stock items
      errorMessage: errorMessage, // Pass potential error message from redirect
      successMessage: successMessage, // Pass potential success message from redirect
    });
  } catch (error) {
    console.error("Error fetching maintenance or stock data:", error);
    // Render the view with empty arrays and an error message
    res.render("manager/manage_maintenance", {
      maintenanceRequests: [], // Provide empty array on error
      stockItems: [], // Provide empty array on error
      errorMessage: "An error occurred loading data. Please try again later.",
      successMessage: "",
    });
  }
});

// Route to update the maintenance request status
router.post("/update_maintenance/:id", async (req, res) => {
  const maintenanceId = req.params.id;
  const { action, item_id, quantity_used } = req.body; // Get action, item_id, quantity_used

  // Handle "Accept" action separately (simpler, no stock involved)
  if (action === "Accepted") {
    try {
      await pool.query(
        "UPDATE maintenance_requests SET status = ? WHERE id = ?",
        [action, maintenanceId]
      );
      // Consider adding a success flash message
      return res.redirect("/manager/manage_maintenance");
    } catch (error) {
      console.error("Error accepting maintenance request:", error);
      // Consider adding an error flash message
      return res.redirect(
        `/manager/manage_maintenance?error=${encodeURIComponent(
          "Failed to accept request."
        )}`
      );
    }
  }

  // --- Handle "Completed" action with stock integration ---
  if (action === "Completed") {
    // Basic backend validation
    if (
      !item_id ||
      !quantity_used ||
      isNaN(quantity_used) ||
      parseInt(quantity_used, 10) <= 0
    ) {
      console.error("Invalid input for completing maintenance:", {
        item_id,
        quantity_used,
      });
      // Add error flash message
      return res.redirect(
        `/manager/manage_maintenance?error=${encodeURIComponent(
          "Invalid item or quantity provided."
        )}`
      );
    }

    const quantityUsedInt = parseInt(quantity_used, 10);
    let connection; // Define connection outside try for rollback/commit in finally

    try {
      connection = await pool.getConnection(); // Get connection for transaction
      await connection.beginTransaction(); // Start transaction

      // 1. Get stock item details and LOCK the row for update
      const [stockItems] = await connection.query(
        "SELECT id, item_name, item_maintenance_type, quantity, unit_price FROM stock_items WHERE id = ? FOR UPDATE",
        [item_id]
      );

      if (!stockItems || stockItems.length === 0) {
        await connection.rollback(); // Rollback transaction
        console.error(`Stock item with ID ${item_id} not found.`);
        // Add error flash message
        return res.redirect(
          `/manager/manage_maintenance?error=${encodeURIComponent(
            "Selected stock item not found."
          )}`
        );
      }

      const stockItem = stockItems[0];

      // 2. Check if sufficient quantity is available
      if (stockItem.quantity < quantityUsedInt) {
        await connection.rollback(); // Rollback transaction
        console.warn(
          `Insufficient stock for item ${stockItem.item_name} (ID: ${item_id}). Needed: ${quantityUsedInt}, Available: ${stockItem.quantity}`
        );
        // Add error flash message
        return res.redirect(
          `/manager/manage_maintenance?error=${encodeURIComponent(
            `Insufficient stock for ${stockItem.item_name}. Only ${stockItem.quantity} available.`
          )}`
        );
      }

      // 3. Get maintenance request details (specifically the type)
      const [requests] = await connection.query(
        "SELECT maintenance_type FROM maintenance_requests WHERE id = ?",
        [maintenanceId]
      );

      if (!requests || requests.length === 0) {
        await connection.rollback();
        console.error(
          `Maintenance request with ID ${maintenanceId} not found.`
        );
        return res.redirect(
          `/manager/manage_maintenance?error=${encodeURIComponent(
            "Maintenance request not found."
          )}`
        );
      }
      const maintenanceRequest = requests[0];

      // 4. Calculate the cost
      const calculatedCost = parseFloat(stockItem.unit_price) * quantityUsedInt;

      // 5. Update stock_items table (decrement quantity)
      await connection.query(
        "UPDATE stock_items SET quantity = quantity - ? WHERE id = ?",
        [quantityUsedInt, item_id]
      );

      // 6. Update maintenance_requests table (status and cost)
      await connection.query(
        "UPDATE maintenance_requests SET status = ?, maintenance_cost = ? WHERE id = ?",
        ["Completed", calculatedCost, maintenanceId]
      );

      // 7. Insert into stock_usage log
      // Note: Handling potential NULLs for *_maintenance_type fields if necessary
      await connection.query(
        `INSERT INTO stock_usage
         (maintenance_id, item_id, quantity_used, item_name, item_maintenance_type, requested_maintenance_type, general_maintenance_id)
         VALUES (?, ?, ?, ?, ?, ?, ?)`, // Still 7 placeholders
        [
          maintenanceId,
          item_id,
          quantityUsedInt,
          stockItem.item_name,
          stockItem.item_maintenance_type,
          maintenanceRequest.maintenance_type,
          null, // <--- CHANGE THIS: Use actual null, not 0
        ]
      );

      // If all queries succeeded, commit the transaction
      await connection.commit();
      /* //debugin line console.log(
        `Maintenance request ${maintenanceId} completed. Stock updated for item ${item_id}. Usage logged.`
      ); */
      // Add success flash message
      return res.redirect(
        `/manager/manage_maintenance?success=${encodeURIComponent(
          "Maintenance completed and stock updated."
        )}`
      );
    } catch (error) {
      console.error(
        "Error completing maintenance request with stock update:",
        error
      );
      // If an error occurred, rollback the transaction
      if (connection) {
        await connection.rollback();
      }
      // Add error flash message
      return res.redirect(
        `/manager/manage_maintenance?error=${encodeURIComponent(
          "An error occurred during completion. Stock not updated."
        )}`
      );
    } finally {
      // Always release the connection back to the pool
      if (connection) {
        connection.release();
      }
    }
  } else {
    // Invalid action if not "Accepted" or "Completed"
    return res.status(400).send("Invalid action specified.");
  }
});

router.get("/maintenance/count", async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT COUNT(*) AS count FROM maintenance_requests WHERE status = 'Pending'"
    );
    res.json({ count: rows[0].count });
  } catch (error) {
    console.error("Error fetching maintenance count:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});
//view maintenace menu
router.get(
  "/general/maintenance/menu",
  isAuthenticated("manager"),
  (req, res) => {
    res.render("manager/general_maintenance_menu");
  }
);

router.get("/general-maintenance", isAuthenticated("manager"), (req, res) => {
  res.render("manager/general_maintenance");
});

//general maintenace
router.post(
  "/general-maintenance",
  isAuthenticated("manager"),
  async (req, res) => {
    const { type, description, other_type } = req.body;

    const maintenanceType = type === "Other" ? other_type : type; // Use custom type if "Other" is selected

    try {
      // Insert new maintenance request into the database
      await pool.query(
        `INSERT INTO general_maintenance (type, description, status, managed_by )
       VALUES (?, ?, ?, ?)`,
        [maintenanceType, description, "Pending", "Manager"]
      );

      res.redirect(
        "/manager/general-maintenance/?success=Maintenance request created successfully"
      );
    } catch (err) {
      console.error(err);
      res.redirect(
        "/manager/general-maintenance/?error=Failed to create maintenance request"
      );
    }
  }
);
router.get(
  "/general-maintenance/view",
  isAuthenticated("manager"), // Assuming isAuthenticated handles session checks
  async (req, res) => {
    try {
      // Fetch all general maintenance requests
      const [generalMaintenance] = await pool.query(
        "SELECT * FROM general_maintenance ORDER BY date_created DESC" // Added ordering
      );

      // Fetch available stock items
      const [stockItems] = await pool.query(
        "SELECT id, item_name, item_maintenance_type,quantity FROM stock_items WHERE quantity > 0 ORDER BY item_name ASC"
      );

      // Check for messages from query parameters
      const errorMessage = req.query.error
        ? decodeURIComponent(req.query.error)
        : "";
      const successMessage = req.query.success
        ? decodeURIComponent(req.query.success)
        : "";

      // Render the EJS template and pass the data
      res.render("manager/view_general_maintenance", {
        generalMaintenance: generalMaintenance,
        stockItems: stockItems, // Pass stock items
        errorMessage: errorMessage,
        successMessage: successMessage,
        error: null, // Compatibility if the template expects 'error' specifically
      });
    } catch (err) {
      console.error("Error fetching general maintenance or stock data:", err);
      res.render("manager/view_general_maintenance", {
        generalMaintenance: [], // Pass empty array on error
        stockItems: [], // Pass empty array on error
        error: "Failed to load maintenance requests", // Specific error message
        errorMessage: "Failed to load maintenance requests", // General error message
        successMessage: "",
      });
    }
  }
);

router.post(
  "/general-maintenance/update",
  isAuthenticated("manager"),
  async (req, res) => {
    // Extract all potential fields from body
    const { id, status, cost, item_id, quantity_used } = req.body;
    const generalMaintenanceId = id; // Use a clearer variable name

    // --- Handle Non-Completion Status Updates (Original Logic) ---
    if (status !== "Completed") {
      try {
        const query = `UPDATE general_maintenance SET status = ?, managed_by = ? WHERE id = ?`;
        const params = [
          status,
          req.session.user?.name || "Manager",
          generalMaintenanceId,
        ]; // Get manager name from session if possible
        await pool.query(query, params);
        return res.redirect(
          `/manager/general-maintenance/view?success=${encodeURIComponent(
            "Status updated successfully"
          )}`
        );
      } catch (err) {
        console.error("Error updating general maintenance status:", err);
        return res.redirect(
          `/manager/general-maintenance/view?error=${encodeURIComponent(
            "Failed to update status"
          )}`
        );
      }
    }

    if (status === "Completed") {
      if (
        !item_id ||
        !quantity_used ||
        isNaN(quantity_used) ||
        parseInt(quantity_used, 10) <= 0
      ) {
        console.error("Invalid input for completing general maintenance:", {
          generalMaintenanceId,
          item_id,
          quantity_used,
        });
        return res.redirect(
          `/manager/general-maintenance/view?error=${encodeURIComponent(
            "Invalid item or quantity provided for completion."
          )}`
        );
      }

      const quantityUsedInt = parseInt(quantity_used, 10);
      let connection;

      try {
        connection = await pool.getConnection();
        await connection.beginTransaction();

        // 1. Get stock item details & lock row
        const [stockItems] = await connection.query(
          "SELECT id, item_name, item_maintenance_type, quantity, unit_price FROM stock_items WHERE id = ? FOR UPDATE",
          [item_id]
        );

        if (!stockItems || stockItems.length === 0) {
          await connection.rollback();
          console.error(
            `Stock item with ID ${item_id} not found for general maintenance ${generalMaintenanceId}.`
          );
          return res.redirect(
            `/manager/general-maintenance/view?error=${encodeURIComponent(
              "Selected stock item not found."
            )}`
          );
        }
        const stockItem = stockItems[0];

        // 2. Check stock quantity
        if (stockItem.quantity < quantityUsedInt) {
          await connection.rollback();
          console.warn(
            `Insufficient stock for item ${stockItem.item_name} (ID: ${item_id}) for general maintenance ${generalMaintenanceId}. Needed: ${quantityUsedInt}, Available: ${stockItem.quantity}`
          );
          return res.redirect(
            `/manager/general-maintenance/view?error=${encodeURIComponent(
              `Insufficient stock for ${stockItem.item_name}. Only ${stockItem.quantity} available.`
            )}`
          );
        }

        const [requests] = await connection.query(
          "SELECT type FROM general_maintenance WHERE id = ?",
          [generalMaintenanceId]
        );
        const maintenanceRequest = requests[0];
        // 3. Calculate cost
        const calculatedCost =
          parseFloat(stockItem.unit_price) * quantityUsedInt;

        // 4. Update stock_items (decrement quantity)
        await connection.query(
          "UPDATE stock_items SET quantity = quantity - ? WHERE id = ?",
          [quantityUsedInt, item_id]
        );

        // 5. Update general_maintenance (status, calculated cost, managed_by)
        await connection.query(
          `UPDATE general_maintenance SET status = ?, cost = ?, managed_by = ? WHERE id = ?`,
          [
            "Completed",
            calculatedCost,
            req.session.user?.name || "Manager",
            generalMaintenanceId,
          ]
        );

        // 6. Insert into stock_usage (linking to general_maintenance_id, tenant maintenance_id is NULL)
        await connection.query(
          `INSERT INTO stock_usage
           (maintenance_id, item_id, quantity_used, item_name, item_maintenance_type, requested_maintenance_type, general_maintenance_id)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            null, // maintenance_id (tenant request) is NULL
            item_id,
            quantityUsedInt,
            stockItem.item_name,
            stockItem.item_maintenance_type,
            maintenanceRequest.type, // Use the type from general maintenance
            null,
            generalMaintenanceId, // Link to the general maintenance task
          ]
        );

        // If all queries succeeded, commit the transaction
        await connection.commit();
        /*//debugin line console.log(
          `General maintenance ${generalMaintenanceId} completed. Stock updated for item ${item_id}. Usage logged.`
        ); */
        return res.redirect(
          `/manager/general-maintenance/view?success=${encodeURIComponent(
            "Maintenance completed and stock updated."
          )}`
        );
      } catch (error) {
        console.error(
          "Error completing general maintenance with stock update:",
          error
        );
        if (connection) {
          await connection.rollback();
        }
        return res.redirect(
          `/manager/general-maintenance/view?error=${encodeURIComponent(
            "An error occurred during completion. Stock not updated."
          )}`
        );
      } finally {
        if (connection) {
          connection.release();
        }
      }
    }
  }
);
//display stoc usage
router.get("/stock-usage", isAuthenticated("manager"), async (req, res) => {
  const { name = "", start, end } = req.query;

  try {
    let query = `
      SELECT 
        su.id,
        su.item_name,
        su.item_maintenance_type,
        su.quantity_used,
        su.used_at,
        su.requested_maintenance_type,
        su.maintenance_id,
        su.general_maintenance_id,
        si.quantity AS current_stock_quantity
      FROM stock_usage su
      JOIN stock_items si ON su.item_id = si.id
      WHERE su.item_name LIKE ?
    `;

    const params = [`%${name}%`];

    if (start && end) {
      query += ` AND DATE(su.used_at) BETWEEN ? AND ?`;
      params.push(start, end);
    }

    query += ` ORDER BY su.used_at DESC`;

    const [stockUsage] = await pool.query(query, params);

    const usageWithSource = stockUsage.map((row) => ({
      ...row,
      maintenance_source: row.maintenance_id
        ? "Tenant Request"
        : "General Maintenance",
    }));

    res.render("manager/stock_usage_view", {
      stockUsage: usageWithSource,
      filters: { name, start, end },
    });
  } catch (err) {
    console.error("Error fetching stock usage:", err);
    res.render("manager/stock_usage_view", {
      stockUsage: [],
      error: "Failed to load stock usage data.",
      filters: { name, start, end },
    });
  }
});

module.exports = router;
