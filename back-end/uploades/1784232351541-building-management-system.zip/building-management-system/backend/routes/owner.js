const express = require("express");
const router = express.Router();
const isAuthenticated = require("../middleware/auth");
const upload = require("../middleware/upload"); // Ensure correct import
const pool = require("../db");

router.get("/dashboard", isAuthenticated("owner"), (req, res) => {
  res.render("owner_dashboard", { username: req.session.user.username });
});

//tenant rports route
router.get("/reports/tenant", isAuthenticated("owner"), async (req, res) => {
  try {
    // Get total number of tenants
    const [[{ total_tenants }]] = await pool.query(
      "SELECT COUNT(*) AS total_tenants FROM tenants"
    );

    // Get breakdown by tenant type (Residential, Business)
    const [tenantBreakdown] = await pool.query(
      "SELECT tenant_type, COUNT(*) AS count FROM tenants GROUP BY tenant_type"
    );

    res.render("owner/tenant_reports", { total_tenants, tenantBreakdown });
  } catch (err) {
    console.error("Error fetching tenant reports:", err);
    res.status(500).send("Internal Server Error");
  }
});

//room reports route
router.get("/reports/room", isAuthenticated("owner"), async (req, res) => {
  try {
    // Get total Business and Resident rooms
    const roomCategoryQuery = `
      SELECT 
        type, 
        COUNT(*) AS count 
      FROM rooms 
      GROUP BY type
    `;
    const [roomCategoryBreakdown] = await pool.query(roomCategoryQuery);

    // Get breakdown of Resident rooms by sub-type (Single, Double, Suite)
    const residentTypeQuery = `
      SELECT resident_type AS room_type, COUNT(*) AS count 
      FROM rooms 
      WHERE type = 'Resident' 
      GROUP BY resident_type
    `;
    const [residentTypeBreakdown] = await pool.query(residentTypeQuery);

    // Get breakdown by room status (Vacant, Occupied)
    const roomStatusQuery = `
      SELECT status AS room_status, COUNT(*) AS count 
      FROM rooms 
      GROUP BY status
    `;
    const [roomStatusBreakdown] = await pool.query(roomStatusQuery);

    // Render the EJS template
    res.render("owner/room_reports", {
      roomCategoryBreakdown, // Business vs. Resident
      residentTypeBreakdown, // Subcategories (Single, Double, Suite)
      roomStatusBreakdown, // Vacant, Occupied
    });
  } catch (error) {
    console.error("Error fetching room reports:", error);
    res.status(500).send("Internal Server Error");
  }
});
// employee reports route
router.get("/reports/employee", isAuthenticated("owner"), async (req, res) => {
  try {
    const totalEmployeesQuery = "SELECT COUNT(*) AS total FROM employees";
    const [[totalEmployees]] = await pool.query(totalEmployeesQuery);

    const roleBreakdownQuery =
      "SELECT role, COUNT(*) AS count FROM employees GROUP BY role";
    const [roleBreakdown] = await pool.query(roleBreakdownQuery);

    const employmentTypeQuery =
      "SELECT employment_type, COUNT(*) AS count FROM employees GROUP BY employment_type";
    const [employmentTypeBreakdown] = await pool.query(employmentTypeQuery);

    const statusQuery =
      "SELECT status, COUNT(*) AS count FROM employees GROUP BY status";
    const [statusBreakdown] = await pool.query(statusQuery);

    res.render("owner/employee_reports", {
      total_employees: totalEmployees.total,
      roleBreakdown: roleBreakdown.length ? roleBreakdown : [],
      employmentTypeBreakdown: employmentTypeBreakdown.length
        ? employmentTypeBreakdown
        : [],
      statusBreakdown: statusBreakdown.length ? statusBreakdown : [],
    });
  } catch (error) {
    console.error("Error fetching employee reports:", error);
    res.status(500).send("Internal Server Error");
  }
});

//payment rports
router.get("/reports/payments", isAuthenticated("owner"), async (req, res) => {
  try {
    // Get total payments breakdown
    const [totalPayments] = await pool.query(`
          SELECT 
              COUNT(*) AS total,
              SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending,
              SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) AS approved,
              SUM(CASE WHEN status = 'Declined' THEN 1 ELSE 0 END) AS declined
          FROM payments
      `);

    // Get overdue payments count
    const [overdueCount] = await pool.query(`
          SELECT COUNT(*) AS overdue
          FROM payments p
          JOIN tenants t ON p.tenant_id = t.id
          WHERE p.status != 'Approved' 
          AND (CURDATE() > p.grace_period_end OR p.grace_period_end IS NULL)
          AND t.tenant_status != 'Terminated'
      `);

    res.render("owner/payment_reports", {
      totalPayments: totalPayments[0],
      overduePayments: overdueCount[0].overdue,
    });
  } catch (error) {
    console.error("Error fetching payment reports:", error);
    res.status(500).send("Internal Server Error");
  }
});

// GET Maintenance Reports
router.get(
  "/reports/maintenance",
  isAuthenticated("owner"),
  async (req, res) => {
    try {
      // Fetch Tenant Maintenance Requests breakdown
      const [tenantMaintenance] = await pool.query(`
          SELECT 
              SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending,
              SUM(CASE WHEN status = 'Accepted' THEN 1 ELSE 0 END) AS accepted,
              SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) AS completed
          FROM maintenance_requests
      `);

      // Fetch Building Maintenance breakdown
      const [buildingMaintenance] = await pool.query(`
          SELECT 
              SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending,
              SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) AS inProgress,
              SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) AS completed
          FROM general_maintenance
      `);

      res.render("owner/maintenance_reports", {
        tenantMaintenance: tenantMaintenance[0],
        buildingMaintenance: buildingMaintenance[0],
      });
    } catch (error) {
      console.error("Error fetching maintenance reports:", error);
      res.status(500).send("Internal Server Error");
    }
  }
);
// Helper function to format dates for MySQL (YYYY-MM-DD)
function formatMySQLDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

router.get("/reports/financial", isAuthenticated("owner"), async (req, res) => {
  try {
    // Get month and year from query params
    const month =
      req.query.month === "all"
        ? null
        : req.query.month
        ? parseInt(req.query.month)
        : new Date().getMonth() + 1;
    const year =
      req.query.year === "all"
        ? null
        : req.query.year
        ? parseInt(req.query.year)
        : new Date().getFullYear();

    // Prepare date filter variables
    let dateFilter = "";
    let dateParams = [];
    let overdueDateFilter = "";
    let overdueDateParams = [];

    if (month && year) {
      // Calculate first and last day of the selected month
      const firstDay = new Date(year, month - 1, 1);
      const lastDay = new Date(year, month, 0);

      // Format dates for MySQL
      const firstDayStr = formatMySQLDate(firstDay);
      const lastDayStr = formatMySQLDate(lastDay);

      dateFilter = "AND created_at BETWEEN ? AND ?";
      dateParams = [firstDayStr, lastDayStr];

      // For overdue payments, we want payments DUE in the selected month that are still unpaid
      overdueDateFilter = "AND due_date BETWEEN ? AND ?";
      overdueDateParams = [firstDayStr, lastDayStr];
    }

    // Revenue from approved payments (using created_at)
    const [revenueResult] = await pool.query(
      `SELECT COALESCE(SUM(amount), 0) AS totalRevenue 
       FROM payments 
       WHERE LOWER(status) = 'approved'
       ${dateFilter}`,
      dateFilter ? ["approved", ...dateParams] : ["approved"]
    );
    const totalRevenue = Number(revenueResult[0]?.totalRevenue) || 0;
    const netIncome = totalRevenue * 0.85;
    const [debugResult] = await pool.query(
      `SELECT amount, created_at 
       FROM payments 
       WHERE status = 'approved'
       ORDER BY created_at DESC`
    );
    console.log(debugResult); // Check if all expected payments are here
    // Employee salaries (no date filter)
    const [salaryResult] = await pool.query(
      `SELECT COALESCE(SUM(salary), 0) AS totalSalaries 
       FROM employees 
       WHERE status != 'Terminated'`
    );
    const totalSalaries = Number(salaryResult[0]?.totalSalaries) || 0;

    // Tenant maintenance costs (using created_at)
    const [tenantMaintenanceResult] = await pool.query(
      `SELECT COALESCE(SUM(maintenance_cost), 0) AS tenantMaintenanceCosts 
       FROM maintenance_requests 
       WHERE status = 'Completed'
       ${dateFilter}`,
      dateFilter ? ["Completed", ...dateParams] : ["Completed"]
    );
    const tenantMaintenanceCosts =
      Number(tenantMaintenanceResult[0]?.tenantMaintenanceCosts) || 0;

    // General maintenance costs (using date_created)
    const [generalMaintenanceResult] = await pool.query(
      `SELECT COALESCE(SUM(cost), 0) AS generalMaintenanceCosts 
       FROM general_maintenance 
       WHERE status = 'Completed'
       ${dateFilter.replace("created_at", "date_created")}`,
      dateFilter ? ["Completed", ...dateParams] : ["Completed"]
    );
    const generalMaintenanceCosts =
      Number(generalMaintenanceResult[0]?.generalMaintenanceCosts) || 0;

    // Stock items cost (using create_at)
    let stockQuery = `SELECT COALESCE(SUM(total_price), 0) AS totalStockCost FROM stock_items`;
    if (month && year) {
      stockQuery += ` WHERE created_at BETWEEN ? AND ?`;
    }
    const [stockCostResult] = await pool.query(
      stockQuery,
      month && year ? dateParams : []
    );
    const totalStockCost = Number(stockCostResult[0]?.totalStockCost) || 0;

    // CORRECTED Overdue payments (using due_date for the selected month)
    const [overdueResult] = await pool.query(
      `SELECT COALESCE(SUM(amount), 0) AS overduePayments 
       FROM payments 
       WHERE LOWER(status) != 'approved'
       ${overdueDateFilter}
       AND due_date < CURDATE()`, // Only payments past their due date
      overdueDateFilter ? overdueDateParams : []
    );
    const overduePayments = Number(overdueResult[0]?.overduePayments) || 0;

    // Total expenses and net profit
    const totalExpenses = totalSalaries + totalStockCost;
    const netProfit = netIncome - totalExpenses;

    res.render("owner/financial_reports", {
      totalRevenue,
      netIncome,
      totalSalaries,
      tenantMaintenanceCosts,
      generalMaintenanceCosts,
      totalStockCost,
      totalExpenses,
      netProfit,
      overduePayments,
      selectedMonth: month,
      selectedYear: year,
      months: Array.from({ length: 12 }, (_, i) => i + 1),
      years: Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i),
      showAll: !month || !year,
      currentMonth: new Date().getMonth() + 1,
      currentYear: new Date().getFullYear(),
    });
  } catch (error) {
    console.error("Error fetching financial data:", error);
    res.status(500).send("Internal Server Error");
  }
});

router.get("/create/menu", isAuthenticated("owner"), (req, res) => {
  res.render("owner/manager_menu");
});
router.get("/employees/create", isAuthenticated("owner"), (req, res) => {
  res.render("owner/create_manager", { error: null }); // Renders the create_room.ejs template
});

//manager creation

router.post(
  "/employees/create",
  isAuthenticated("owner"),
  upload.fields([
    { name: "id_card", maxCount: 1 },
    { name: "co_signer_id_card", maxCount: 1 },
    { name: "co_signer_lease", maxCount: 1 },
  ]),
  async (req, res) => {
    const {
      fullname,
      age,
      gender,
      role,
      co_signer_fullname,
      salary,
      employment_date,
      contact_info,
      status,
      cosigner_contactinfo,
      employee_type,
      leave_days,
    } = req.body;

    // Retrieve filenames of uploaded images (if available)
    const idCardImage = req.files?.id_card
      ? req.files["id_card"][0].filename
      : null;
    const coSignerIdCardImage = req.files?.co_signer_id_card
      ? req.files["co_signer_id_card"][0].filename
      : null;
    const coSignerLease = req.files?.co_signer_lease
      ? req.files["co_signer_lease"][0].filename
      : null;

    // Set default leave_days to 15 if not provided
    const leaveDays = leave_days ? parseInt(leave_days, 10) : 15;

    console.log("Received data:", {
      fullname,
      age,
      gender,
      role,
      salary,
      employment_date,
      status,
      idCardImage,
      coSignerIdCardImage,
      coSignerLease,
      employee_type,
      leaveDays,
    });

    // Input validation
    if (
      !fullname ||
      !age ||
      !gender ||
      !role ||
      !salary ||
      !employment_date ||
      !status ||
      !idCardImage ||
      !coSignerIdCardImage ||
      !coSignerLease ||
      !employee_type
    ) {
      return res.render("manager/create_employee", {
        error: "All fields are required!",
      });
    }

    try {
      // Insert employee details into the database
      await pool.execute(
        `INSERT INTO employees 
        (fullname, id_card, age, gender, role, co_signer_fullname, co_signer_id_card, co_signer_lease, salary, employment_date, contact_info, status, cosigner_contactinfo, employment_type, leave_days)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          fullname,
          idCardImage,
          age,
          gender,
          role,
          co_signer_fullname,
          coSignerIdCardImage,
          coSignerLease,
          salary,
          employment_date,
          contact_info || null, // Ensure null instead of undefined
          status,
          cosigner_contactinfo || null, // Ensure null instead of undefined
          employee_type,
          leaveDays, // Ensure leaveDays is always defined
        ]
      );

      res.redirect(
        "/owner/employees/create?success=Employee created successfully!"
      );
    } catch (err) {
      console.error("Error creating employee:", err);
      res.render("owner/create_manager", {
        error: "Failed to create employee.",
      });
    }
  }
);
// Route to view a single employee
router.get("/employee/view", isAuthenticated("owner"), async (req, res) => {
  try {
    // Fetch employees from the database
    const [employees] = await pool.query(`
      SELECT * FROM employees where status != 'Terminated' AND role = 'Manager'
    `);

    // Format the date and other fields as needed
    employees.forEach((employee) => {
      employee.contact_info = employee.contact_info || "Not Provided"; // Ensure contact info is displayed
      employee.salary = employee.salary || "Not Set"; // Ensure salary is displayed
      employee.status = employee.status || "Inactive"; // Ensure status is displayed
    });

    // Render the view with the employees
    res.render("owner/view_manager", { employees });
  } catch (err) {
    console.error(err);
    res.redirect("/owner/employee/view?error=Failed to load employees.");
  }
});

// View More Employee Details Route
router.get(
  "/employee/viewMore/:id",
  isAuthenticated("owner"),
  async (req, res) => {
    const { id } = req.params;

    try {
      // Query to fetch detailed employee information
      const [employeeDetails] = await pool.query(
        `
        SELECT * FROM employees WHERE id = ?
        `,
        [id]
      );

      if (employeeDetails.length > 0) {
        const employee = employeeDetails[0];
        res.render("owner/view_more_manager", { employee }); // Render the detailed page
      } else {
        res.redirect("/owner/employee/view?error=Employee not found.");
      }
    } catch (err) {
      console.error(err);
      res.redirect(
        "/owner/employee/view?error=Failed to load employee details."
      );
    }
  }
);

// Route to toggle employee status
router.post(
  "/employee/toggle-status/:id",
  isAuthenticated("owner"),
  async (req, res) => {
    const employeeId = req.params.id;
    const { leaveDays, leaveMonth } = req.body;

    try {
      // Fetch the current status and leave days of the employee
      const [employee] = await pool.execute(
        "SELECT status, leave_days FROM employees WHERE id = ?",
        [employeeId]
      );

      // Check if the employee exists
      if (employee.length === 0) {
        return res.redirect("/owner/employee/view?error=Employee not found.");
      }

      const currentStatus = employee[0].status;
      const currentLeaveDays = employee[0].leave_days || 0;
      const newStatus = currentStatus === "Active" ? "Inactive" : "Active";

      // Prepare update parameters
      let updateQuery = "UPDATE employees SET status = ?";
      const updateParams = [newStatus];

      // If deactivating, process leave days
      if (currentStatus === "Active" && newStatus === "Inactive") {
        if (!leaveDays || !leaveMonth) {
          return res.redirect(
            "/owner/employee/view?error=Leave days and month are required when deactivating."
          );
        }

        const parsedLeaveDays = parseInt(leaveDays);
        if (isNaN(parsedLeaveDays) || parsedLeaveDays < 0) {
          return res.redirect(
            "/owner/employee/view?error=Invalid leave days value."
          );
        }

        if (parsedLeaveDays > currentLeaveDays) {
          return res.redirect(
            `/owner/employee/view?error=Taken leave days (${parsedLeaveDays}) cannot exceed available leave days (${currentLeaveDays}).`
          );
        }

        const newLeaveDays = currentLeaveDays - parsedLeaveDays;

        updateQuery +=
          ", leave_days = ?, taken_leave_days = ?, leave_month = ?";
        updateParams.push(newLeaveDays, parsedLeaveDays, leaveMonth);
      }

      updateParams.push(employeeId);

      // Execute the update
      await pool.execute(`${updateQuery} WHERE id = ?`, updateParams);

      res.redirect("/owner/employee/view?success=Employee status updated.");
    } catch (err) {
      console.error("Error updating status:", err);
      res.redirect(
        "/owner/employee/view?error=Failed to update employee status."
      );
    }
  }
);
// Route for updating employee
router.post(
  "/employee/update/:id",
  isAuthenticated("owner"),
  upload.single("id_card"),
  (req, res, next) => {
    // Handle Multer file upload errors
    if (req.fileValidationError) {
      return res.status(400).send(req.fileValidationError);
    }
    next();
  },
  async (req, res) => {
    try {
      const { id } = req.params;
      const {
        fullname,
        age,
        role,
        contact_info,
        salary,
        status,
        gender,
        co_signer_fullname,
        cosigner_contactinfo,
        employee_type,
      } = req.body;

      // Handle file upload if a new file is provided
      const id_card = req.file ? req.file.path : null;

      // Check if employee exists
      const [existingEmployee] = await pool.query(
        "SELECT * FROM employees WHERE id = ?",
        [id]
      );
      if (existingEmployee.length === 0) {
        return res.redirect("/owner/employee/view?error=Employee not found.");
      }

      // Sanitize fields by replacing empty strings or undefined with null
      const fields = {
        fullname: fullname || null,
        age: age || null,
        role: role || null,
        contact_info: contact_info || null,
        salary: salary || null,
        status: status || null,
        gender: gender || null,
        co_signer_fullname: co_signer_fullname || null,
        cosigner_contactinfo: cosigner_contactinfo || null,
        employee_type: employee_type || null,
      };

      // Build the query dynamically
      let query = `UPDATE employees SET fullname = ?, age = ?, role = ?, contact_info = ?, salary = ?, status = ?, gender = ?, co_signer_fullname = ?, cosigner_contactinfo = ?, employment_type = ?`;
      let values = [
        fields.fullname,
        fields.age,
        fields.role,
        fields.contact_info,
        fields.salary,
        fields.status,
        fields.gender,
        fields.co_signer_fullname,
        fields.cosigner_contactinfo,
        fields.employee_type,
      ];

      // Add id_card to the query if provided
      if (id_card) {
        query += `, id_card = ?`;
        values.push(id_card);
      }

      query += ` WHERE id = ?`;
      values.push(id);

      // Execute the update query
      await pool.execute(query, values);

      // Redirect to the employee view page with a success message
      res.redirect(
        "/owner/employee/view?success=Employee updated successfully!"
      );
    } catch (err) {
      console.error(err);
      res.redirect("/owner/employee/view?error=Failed to update employee.");
    }
  }
);

// Route to load employee update form (GET)
router.get(
  "/employee/update/:id",
  isAuthenticated("owner"),
  async (req, res) => {
    try {
      const { id } = req.params;

      // Fetch the employee data from the database
      const [employees] = await pool.execute(
        "SELECT * FROM employees WHERE id = ?",
        [id]
      );

      if (employees.length === 0) {
        return res.redirect("/owner/employee/view?error=Employee not found.");
      }

      const employee = employees[0];

      // Render the update form, passing employee data to the template
      res.render("owner/update_manager", { employee: employee });
    } catch (err) {
      console.error(err);
      res.redirect(
        "/owner/employee/view?error=Failed to load employee for update."
      );
    }
  }
);

// Route to terminate an employee
router.post(
  "/manager/terminate/:id",
  isAuthenticated("owner"),
  async (req, res) => {
    const { id } = req.params;

    try {
      // Update the status of the employee to 'Terminated'
      await pool.query(
        `UPDATE employees SET status = 'Terminated' WHERE id = ?`,
        [id]
      );

      // Redirect to the employee view page with success message
      res.redirect(
        "/owner/employee/view?success=Employee terminated successfully."
      );
    } catch (err) {
      console.error(err);
      res.redirect("/owner/employee/view?error=Failed to terminate employee.");
    }
  }
);

// Route to view terminated employees
router.get(
  "/manager/terminated",
  isAuthenticated("owner"),
  async (req, res) => {
    try {
      // Fetch employees with the status 'Terminated'
      const [terminatedEmployees] = await pool.query(`
      SELECT * FROM employees WHERE status = 'Terminated' AND role = 'Manager';
    `);

      // Format the data for terminated employees
      terminatedEmployees.forEach((employee) => {
        employee.contact_info = employee.contact_info || "Not Provided";
        employee.salary = employee.salary || "Not Set";
        employee.status = employee.status || "Terminated";
      });

      // Render the terminated employees page, passing 'employees' to EJS
      res.render("owner/view_terminated_manager", {
        employees: terminatedEmployees,
      });
    } catch (err) {
      console.error(err);
      res.redirect(
        "/owner/manager/view?error=Failed to load terminated employees."
      );
    }
  }
);

// View More terminated Employee Details Route
router.get(
  "/manager/viewMore/terminated/:id",
  isAuthenticated("owner"),
  async (req, res) => {
    const { id } = req.params;

    try {
      // Query to fetch detailed employee information
      const [employeeDetails] = await pool.query(
        `
        SELECT * FROM employees WHERE id = ?
        `,
        [id]
      );

      if (employeeDetails.length > 0) {
        const employee = employeeDetails[0];
        res.render("owner/view_more_terminated_manager", { employee }); // Render the detailed page
      } else {
        res.redirect("/owner/manager/view?error=Employee not found.");
      }
    } catch (err) {
      console.error(err);
      res.redirect(
        "/owner/manager/view?error=Failed to load employee details."
      );
    }
  }
);

router.get("/leave/history", isAuthenticated("owner"), async (req, res) => {
  try {
    // Query to get employees with leave information
    const [employees] = await pool.execute(`
      SELECT 
        id,
        fullname AS employee_name,
        role AS employee_role,
        taken_leave_days,
        leave_month,
        status
      FROM 
        employees
      WHERE 
        taken_leave_days > 0
        AND leave_month IS NOT NULL AND role = 'Manager'
      ORDER BY 
        leave_month DESC, employee_name ASC
    `);

    // Format the data for display
    const leaveHistory = employees.map((employee) => ({
      employee_name: employee.employee_name,
      employee_role: employee.employee_role,
      taken_leave_days: `${employee.taken_leave_days} day${
        employee.taken_leave_days !== 1 ? "s" : ""
      }`,
      leave_month: employee.leave_month,
      status: employee.status,
    }));

    res.render("owner/leave_history", {
      title: "Leave History",
      leaveHistory: leaveHistory,
      success: req.query.success,
      error: req.query.error,
    });
  } catch (err) {
    console.error("Error fetching leave history:", err);
    res.redirect("/owner/create/menu?error=Failed to load leave history");
  }
});
module.exports = router;
