const express = require("express");

const router = express.Router();
const isAuthenticated = require("../middleware/auth");
const multer = require("multer");
const path = require("path");
const pool = require("../db"); // Use pool correctly
const { generatePaymentRef } = require("../utils/helpers");

// Configure Multer for receipt uploads
const storage = multer.diskStorage({
  destination: "./uploads/receipts/",
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "application/pdf"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only JPEG, PNG, and PDF allowed."));
    }
  },
});

// Tenant Dashboard Route
router.get("/dashboard", isAuthenticated("tenant"), (req, res) => {
  res.render("tenant_dashboard", { username: req.session.user.username });
});

// tentas view paymetn route
router.get("/payment", isAuthenticated("tenant"), (req, res) => {
  res.render("tenants/payment", {
    username: req.session.user.username,
    tenant_id: req.session.user.id,
  });
});
router.get("/maintenance", isAuthenticated("tenant"), (req, res) => {
  res.render("tenants/maintenance_menu", {
    username: req.session.user.username,
    tenant_id: req.session.user.id,
  });
});

//route to view upload form
router.get("/upload_payment", isAuthenticated("tenant"), async (req, res) => {
  try {
    const user_id = req.session.user.id; // The session contains user_id, not tenant_id

    // Fetch tenant ID using user_id
    const [tenantResult] = await pool.query(
      "SELECT id, room_number FROM tenants WHERE user_id = ?",
      [user_id]
    );

    if (tenantResult.length === 0) {
      return res.status(404).json({ message: "Tenant not found in database." });
    }

    const tenant_id = tenantResult[0].id;
    const room_number = tenantResult[0].room_number;

    // Store tenant_id in session for future use
    req.session.user.tenant_id = tenant_id;

    // Fetch the rent for the assigned room
    const [roomResult] = await pool.query(
      "SELECT rent FROM rooms WHERE room_number = ?",
      [room_number]
    );

    if (roomResult.length === 0) {
      return res.status(404).json({ message: "Room not found." });
    }

    const rentAmount = roomResult[0].rent;

    res.render("tenants/upload_payment", {
      username: req.session.user.username, // Use the session username
      tenant_id,
      room_number,
      rentAmount, // Pass rent to frontend
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error." });
  }
});

// Route to handle the payment upload form submission
router.post("/upload_payment", upload.single("receipt"), async (req, res) => {
  try {
    const { tenant_id, payment_year } = req.body;
    let { payment_months } = req.body;
    const receipt = req.file ? req.file.filename : null;

    // Ensure payment_months is an array
    if (!Array.isArray(payment_months)) {
      payment_months = [payment_months];
    }

    // Fetch tenant's room number
    const [tenantRows] = await pool.query(
      "SELECT room_number FROM tenants WHERE id = ?",
      [tenant_id]
    );
    if (tenantRows.length === 0) {
      return res.status(404).json({ message: "Tenant not found." });
    }
    const room_number = tenantRows[0].room_number;

    // Fetch rent
    const [roomRows] = await pool.query(
      "SELECT rent FROM rooms WHERE room_number = ?",
      [room_number]
    );
    if (roomRows.length === 0) {
      return res.status(404).json({ message: "Room not found." });
    }
    const rentAmount = roomRows[0].rent;

    // Prevent duplicate uploads
    const duplicateCheckPromises = payment_months.map((month) =>
      pool.query(
        `SELECT * FROM payments
         WHERE tenant_id = ? AND payment_month = ? AND payment_year = ? AND status != 'declined'`,
        [tenant_id, month, payment_year]
      )
    );
    const duplicateCheckResults = await Promise.all(duplicateCheckPromises);
    const hasDuplicates = duplicateCheckResults.some(
      ([rows]) => rows.length > 0
    );

    if (hasDuplicates) {
      return res.send(
        `<script>
          alert("Payment already uploaded for one or more selected months.");
          window.location.href='/tenant/upload_payment';
        </script>`
      );
    }

    // Insert one row per month
    for (const month of payment_months) {
      const payment_reference = generatePaymentRef();

      // Calculate due date and grace period
      const dueDate = new Date(`${month} 1, ${payment_year}`);
      const gracePeriodEnd = new Date(dueDate);
      gracePeriodEnd.setDate(gracePeriodEnd.getDate() + 5);

      await pool.query(
        `INSERT INTO payments (
          tenant_id, amount, payment_reference, receipt, status,
          payment_month, payment_year, created_at, due_date, grace_period_end
        ) VALUES (?, ?, ?, ?, 'pending', ?, ?, NOW(), ?, ?)`,
        [
          tenant_id,
          rentAmount,
          payment_reference,
          receipt,
          month,
          payment_year,
          dueDate,
          gracePeriodEnd,
        ]
      );
    }

    res.send(
      `<script>
        alert("Payment uploaded successfully!");
        window.location.href='/tenant/upload_payment';
      </script>`
    );
  } catch (error) {
    console.error("Tenant payment upload error:", error);
    res.send(
      `<script>
        alert("Error uploading payment. Please try again later.");
        window.history.back();
      </script>`
    );
  }
});

// View Payment History
router.get("/history", isAuthenticated("tenant"), async (req, res) => {
  try {
    const user_id = req.session.user.id; // User ID from session

    // Get tenant_id from the tenants table
    const [tenantResult] = await pool.query(
      "SELECT id FROM tenants WHERE user_id = ?",
      [user_id]
    );

    if (tenantResult.length === 0) {
      return res.status(404).json({ message: "Tenant not found." });
    }

    const tenant_id = tenantResult[0].id;

    // Get payment history including manager note and receipt (even for declined)
    const [payments] = await pool.query(
      `SELECT 
        payment_month, 
        payment_year, 
        amount, 
        status, 
        created_at,
        manager_note,
        receipt
      FROM payments 
      WHERE tenant_id = ? 
      ORDER BY created_at DESC`,
      [tenant_id]
    );

    // Render the payments view with payments data
    res.render("tenants/view_payment_history", { payments });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error." });
  }
});

// route to request maintenace
router.get("/request_maintenance", (req, res) => {
  if (!req.session.user || req.session.user.role !== "tenant") {
    return res.redirect("/login");
  }

  res.render("tenants/request_maintenance", {
    errorMessage: null,
    successMessage: null,
  });
});

// Handle Maintenance Request Submission
router.post("/request_maintenance", async (req, res) => {
  try {
    if (!req.session.user || req.session.user.role !== "tenant") {
      return res.redirect("/login");
    }

    const tenant_id = req.session.user.id;
    const { maintenance_type, maintenance_request } = req.body;

    // Fetch tenant details (name & room number)
    const [tenantRows] = await pool.query(
      "SELECT full_name, room_number FROM tenants WHERE user_id = ?",
      [tenant_id]
    );

    if (tenantRows.length === 0) {
      return res.render("tenants/request_maintenance", {
        errorMessage: "Tenant details not found.",
        successMessage: null, // Ensure both variables exist
      });
    }

    const tenant_name = tenantRows[0].full_name;
    const room_number = tenantRows[0].room_number;

    // Insert maintenance request into the database
    await pool.query(
      "INSERT INTO maintenance_requests (tenant_id, tenant_name, room_number, maintenance_request, maintenance_type, status) VALUES (?, ?, ?, ?, ?, 'Pending')",
      [
        tenant_id,
        tenant_name,
        room_number,
        maintenance_request,
        maintenance_type,
      ]
    );

    res.render("tenants/request_maintenance", {
      successMessage: "Maintenance request submitted successfully!",
      errorMessage: null, // Ensure both variables exist
    });
  } catch (error) {
    console.error("Error submitting maintenance request:", error);
    res.render("tenants/request_maintenance", {
      errorMessage: "An error occurred. Please try again later.",
      successMessage: null, // Ensure both variables exist
    });
  }
});

// Route to view profile
router.get("/manage_profile", async (req, res) => {
  if (!req.session.user || req.session.user.role !== "tenant") {
    return res.redirect("/login");
  }

  const tenant_id = req.session.user.id;

  // Fetch current username
  const [userRows] = await pool.query(
    "SELECT username FROM users WHERE id = ?",
    [tenant_id]
  );

  if (userRows.length === 0) {
    return res.redirect("/tenant/dashboard");
  }

  res.render("tenants/manage_profile", {
    user: userRows[0],
    successMessage: null,
    errorMessage: null,
  });
});

//route to handel profile update
const bcrypt = require("bcrypt");

router.post("/manage_profile", async (req, res) => {
  try {
    if (!req.session.user || req.session.user.role !== "tenant") {
      return res.redirect("/login");
    }

    const tenant_id = req.session.user.id;
    const { username, old_password, new_password } = req.body;

    // Fetch the current password hash
    const [userRows] = await pool.query(
      "SELECT username, password FROM users WHERE id = ?",
      [tenant_id]
    );

    if (userRows.length === 0) {
      return res.redirect("/tenant/dashboard");
    }

    const storedPasswordHash = userRows[0].password;

    // Compare old password
    const passwordMatch = await bcrypt.compare(
      old_password,
      storedPasswordHash
    );
    if (!passwordMatch) {
      return res.render("tenants/manage_profile", {
        user: { username: userRows[0].username },
        errorMessage: "Incorrect current password!",
        successMessage: null,
      });
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(new_password, 10);

    // Update username & password in the database
    await pool.query(
      "UPDATE users SET username = ?, password = ? WHERE id = ?",
      [username, hashedPassword, tenant_id]
    );

    res.render("tenants/manage_profile", {
      user: { username },
      successMessage: "Profile updated successfully!",
      errorMessage: null,
    });
  } catch (error) {
    console.error("Error updating profile:", error);
    res.render("tenants/manage_profile", {
      user: { username: req.body.username },
      errorMessage: "An error occurred. Please try again later.",
      successMessage: null,
    });
  }
});

// Route to display maintenance requests for the tenant
router.get("/manage_maintenance", async (req, res) => {
  try {
    if (!req.session.user || req.session.user.role !== "tenant") {
      return res.redirect("/login");
    }

    const tenantId = req.session.user.id; // Assuming tenant's ID is stored in session

    // Fetch all maintenance requests for the logged-in tenant
    const [maintenanceRequests] = await pool.query(
      "SELECT * FROM maintenance_requests WHERE tenant_id = ?",
      [tenantId]
    );

    // Render the view and pass maintenanceRequests
    res.render("tenants/manage_maintenance", {
      maintenanceRequests,
    });
  } catch (error) {
    console.error("Error fetching tenant maintenance requests:", error);
    res.render("tenants/manage_maintenance", {
      errorMessage: "An error occurred. Please try again later.",
    });
  }
});

module.exports = router;
