// routes/auth.js
const express = require("express");
const bcrypt = require("bcrypt");
const pool = require("../db"); // MySQL connection
const session = require("express-session");
const router = express.Router();

// User Registration Route
router.post("/register", async (req, res) => {
  const { username, password, role, email } = req.body;

  // Ensure role is only "manager" or "owner"
  if (
    role !== "manager" &&
    role !== "owner" &&
    role !== "finance" &&
    role !== "stock_manager"
  ) {
    return res.redirect(
      "/register?registrationError=" +
        encodeURIComponent("Invalid role selected.")
    );
  }

  // Check if a manager or owner already exists
  const [existingRole] = await pool.execute(
    "SELECT * FROM users WHERE role = ?",
    [role]
  );

  if (existingRole.length > 0) {
    return res.redirect(
      "/register?registrationError=" +
        encodeURIComponent(
          role.charAt(0).toUpperCase() + role.slice(1) + " already exists!"
        )
    );
  }

  // Check if all fields are provided
  if (!username || !password || !email) {
    return res.redirect(
      "/register?registrationError=" +
        encodeURIComponent("All fields are required!")
    );
  }

  // Check if the username already exists
  const [existingUser] = await pool.execute(
    "SELECT * FROM users WHERE username = ?",
    [username]
  );

  if (existingUser.length > 0) {
    return res.redirect(
      "/register?registrationError=" +
        encodeURIComponent("Username already taken!")
    );
  }

  // Hash the password before storing it
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    // Insert user into database
    await pool.execute(
      "INSERT INTO users (username, password, role, email) VALUES (?, ?, ?, ?)",
      [username, hashedPassword, role, email]
    );

    // Redirect to login page with success message
    res.redirect("/register?registrationSuccess=true");
  } catch (err) {
    console.error(err);
    res.redirect(
      "/register?registrationError=" +
        encodeURIComponent("Registration failed. Please try again.")
    );
  }
});

// User Login Route
router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.redirect("/login?error=Username and password are required!");
  }

  try {
    const [user] = await pool.execute(
      "SELECT * FROM users WHERE username = ?",
      [username]
    );

    if (user.length === 0) {
      return res.redirect("/login?error=User not found!");
    }

    const match = await bcrypt.compare(password, user[0].password);

    if (!match) {
      return res.redirect("/login?error=Invalid credentials!");
    }

    req.session.user = {
      id: user[0].id,
      username: user[0].username,
      role: user[0].role,
    };

    // Redirect based on role
    if (user[0].role === "manager") {
      return res.redirect("/manager/dashboard");
    } else if (user[0].role === "owner") {
      return res.redirect("/owner/dashboard");
    } else if (user[0].role === "tenant") {
      return res.redirect("/tenant/dashboard");
    } else if (user[0].role === "finance") {
      return res.redirect("/finance/dashboard");
    } else if (user[0].role === "stock_manager") {
      return res.redirect("/stock/dashboard");
    }

    res.redirect("/login"); // Default fallback
  } catch (err) {
    console.error(err);
    res.redirect("/login?error=Server error, try again.");
  }
});
// Owner Dashboard Route

router.get("/owner/dashboard", (req, res) => {
  if (!req.session.user || req.session.user.role !== "owner") {
    return res.redirect("/login"); // Redirect to login if not logged in as owner
  }

  // Render the Owner Dashboard and pass username
  res.render("owner_dashboard", { username: req.session.user.username });
});

// Logout Route (Corrected)
router.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error("Logout error:", err);
      return res.redirect("/?error=Logout failed");
    }

    res.set("Cache-Control", "no-store, no-cache, must-revalidate, private");

    res.redirect("/login");
  });
});

module.exports = router;
