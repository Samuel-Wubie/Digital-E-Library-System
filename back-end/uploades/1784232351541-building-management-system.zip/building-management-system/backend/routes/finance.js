const express = require("express");
const pool = require("../db"); // MySQL connection
const multer = require("multer");
const path = require("path");
const bcrypt = require("bcrypt");
const isAuthenticated = require("../middleware/auth"); // Import auth middleware
const moment = require("moment"); // Import moment
const router = express.Router();
const { generatePaymentRef } = require("../utils/helpers");

router.get("/dashboard", isAuthenticated("finance"), (req, res) => {
  res.render("finance_dashboard", { username: req.session.user.username });
});

const storage = multer.diskStorage({
  destination: "./uploads/receipts/",
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "application/pdf"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only JPEG, PNG, and PDF allowed."));
    }
  },
});

router.get("/tenants/view", isAuthenticated("finance"), async (req, res) => {
  try {
    // Fetch tenants from the database, including room and business details
    const [tenants] = await pool.query(`
    SELECT
      tenants.*,
      rooms.room_number,  
      CASE
        WHEN businesses.business_name IS NOT NULL THEN 'Business'
        ELSE 'Residential'
      END AS tenant_type
    FROM tenants 
  
    LEFT JOIN rooms ON tenants.room_number = rooms.room_number  -- ✅ Use room_number instead of room_id
    LEFT JOIN businesses ON tenants.id = businesses.tenant_id 
    WHERE tenant_status != 'Terminated' AND lease_end >= CURDATE()
  `);

    // Format lease start and end dates using moment
    tenants.forEach((tenant) => {
      tenant.lease_start_formatted = moment(tenant.lease_start).format(
        "YYYY-MM-DD"
      );
      tenant.lease_end_formatted = moment(tenant.lease_end).format(
        "YYYY-MM-DD"
      );
    });

    // Render the view with the tenants
    res.render("finance/view_tenants", { tenants });
  } catch (err) {
    console.error(err);
    res.redirect("/manager/tenants/view?error=Failed to load tenants.");
  }
});

// Route to view more details about a specific tenant
router.get(
  "/tenant/viewMore/:id",
  isAuthenticated("finance"),
  async (req, res) => {
    const { id } = req.params;
    try {
      const [tenantDetails] = await pool.query(
        `SELECT
            tenants.*,
            rooms.room_number,  
            businesses.business_name,
            businesses.business_type,
            businesses.license_number,
            businesses.license_image
          FROM tenants 
          LEFT JOIN rooms ON tenants.room_number = rooms.room_number  -- ✅ Use room_number instead of room_id
          LEFT JOIN businesses ON tenants.id = businesses.tenant_id
          WHERE tenants.id = ? `,
        [id]
      );

      if (tenantDetails.length > 0) {
        const tenant = tenantDetails[0];

        // Format lease dates correctly
        tenant.lease_start_formatted = moment(tenant.lease_start).format(
          "YYYY-MM-DD"
        );
        tenant.lease_end_formatted = moment(tenant.lease_end).format(
          "YYYY-MM-DD"
        );

        res.render("finance/view_more_tenant", { tenant });
      } else {
        res.redirect("/finance/tenants/view?error=Tenant not found.");
      }
    } catch (err) {
      console.error(err);
      res.redirect(
        "/finance/tenants/view?error=Failed to load tenant details."
      );
    }
  }
);

router.get("/payments/menu", isAuthenticated("finance"), (req, res) => {
  res.render("finance/payments_menu");
});
//route to mannage payment
router.get("/tenants/payment", isAuthenticated("finance"), async (req, res) => {
  try {
    // Query to fetch tenants with their payments, including the receipt
    const [tenants] = await pool.query(`
        SELECT tenants.id, tenants.full_name, tenants.room_number, 
               payments.id AS payment_id, payments.amount, payments.status, 
               CONCAT(payments.payment_year, '-', payments.payment_month) AS payment_period,
               payments.receipt
        FROM tenants
        LEFT JOIN payments ON tenants.id = payments.tenant_id
        WHERE tenants.tenant_status != 'Terminated'  AND lease_end >= CURDATE();
      `);

    // Grouping payments by tenant
    const tenantData = tenants.reduce((acc, tenant) => {
      const {
        id,
        full_name,
        room_number,
        payment_id,
        amount,
        status,
        payment_period,
        receipt,
      } = tenant;

      if (!acc[id]) {
        acc[id] = {
          id,
          full_name,
          room_number,
          payments: [],
        };
      }
      if (payment_id) {
        acc[id].payments.push({
          id: payment_id,
          amount,
          status,
          payment_period,
          receipt, // Include receipt
        });
      }
      return acc;
    }, {});

    // Pass the formatted tenant data to the view
    res.render("finance/tenants_payment", {
      tenants: Object.values(tenantData),
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error." });
  }
});

router.get("/payment/count", async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT COUNT(*) AS count FROM payments WHERE status = 'Pending'"
    );
    res.json({ count: rows[0].count });
  } catch (error) {
    console.error("Error fetching maintenance count:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

//route to update payment status
router.post(
  "/tenants/payment/update",
  isAuthenticated("finance"),
  async (req, res) => {
    try {
      const { paymentId, status, manager_note } = req.body;

      // Ensure valid status values
      if (!["approved", "declined"].includes(status)) {
        return res.status(400).json({ message: "Invalid status value." });
      }
      let updateQuery = "UPDATE payments SET status = ?";
      let updateParams = [status];
      if (status === "approved") {
        updateQuery = "UPDATE payments SET status = ?, approved_at = NOW()";
        updateParams = [status];
      }

      if (status === "declined" && manager_note) {
        updateQuery += ", manager_note = ?";
        updateParams.push(manager_note); // Add manager_note at the END
      } else {
        updateQuery += ", manager_note = NULL"; // Ensure manager_note is always handled
      }

      updateQuery += " WHERE id = ?";
      updateParams.push(paymentId); // paymentId should always be the last parameter

      const [result] = await pool.query(updateQuery, updateParams);

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Payment not found." });
      }

      res.json({ message: `Payment status updated to ${status}.` });
    } catch (error) {
      console.error("Error updating payment status:", error);
      res.status(500).json({ message: "Server error." });
    }
  }
);

// GET: View Upload Form
// route to view upload form
router.get("/upload_payment", isAuthenticated("finance"), async (req, res) => {
  try {
    // Get all tenants for dropdown
    const [tenants] = await pool.query(`
    SELECT tenants.id, tenants.full_name, tenants.room_number, rooms.rent
    FROM tenants
    JOIN users ON tenants.user_id = users.id
    JOIN rooms ON tenants.room_number = rooms.room_number  WHERE tenants.tenant_status != 'Terminated' AND lease_end >= CURDATE();
  `);

    res.render("finance/upload_payment", {
      username: req.session.user.username,
      tenants,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error." });
  }
});

// POST: Handle Form Submission
router.post("/upload_payment", upload.single("receipt"), async (req, res) => {
  try {
    const { tenant_id, payment_year } = req.body;
    let payment_months = req.body.payment_months || req.body.payment_month;
    const receipt = req.file ? req.file.filename : null;

    // Convert to array if single month
    if (!Array.isArray(payment_months)) {
      payment_months = [payment_months];
    }

    // Fetch tenant's room
    const [tenantRows] = await pool.query(
      "SELECT room_number FROM tenants WHERE id = ?",
      [tenant_id]
    );
    if (tenantRows.length === 0) {
      return res.status(404).json({ message: "Tenant not found." });
    }
    const room_number = tenantRows[0].room_number;

    // Fetch rent amount
    const [roomRows] = await pool.query(
      "SELECT rent FROM rooms WHERE room_number = ?",
      [room_number]
    );
    if (roomRows.length === 0) {
      return res.status(404).json({ message: "Room not found." });
    }
    const rentAmount = roomRows[0].rent;

    // Check for duplicate payments
    const duplicateCheckPromises = payment_months.map((month) =>
      pool.query(
        `SELECT * FROM payments 
         WHERE tenant_id = ? 
         AND payment_month = ? 
         AND payment_year = ? 
         AND status IN ('approved', 'pending')`,
        [tenant_id, month, payment_year]
      )
    );
    const duplicateCheckResults = await Promise.all(duplicateCheckPromises);
    const hasDuplicates = duplicateCheckResults.some(
      (result) => result[0].length > 0
    );

    if (hasDuplicates) {
      return res.send(
        `<script>
          alert("Payment already exists for one or more selected months.");
          window.location.href='/finance/upload_payment';
        </script>`
      );
    }

    // Insert one row per month
    for (const month of payment_months) {
      const payment_reference = generatePaymentRef(); // Unique for each month

      // Calculate due and grace period based on month/year
      const dueDate = new Date(`${month} 1, ${payment_year}`);
      const gracePeriodEnd = new Date(dueDate);
      gracePeriodEnd.setDate(gracePeriodEnd.getDate() + 5);

      await pool.query(
        `INSERT INTO payments (
          tenant_id, amount, payment_reference, 
          receipt, status, payment_month, 
          payment_year, created_at, due_date, 
          grace_period_end
        ) VALUES (?, ?, ?, ?, 'approved', ?, ?, NOW(), ?, ?)`,
        [
          tenant_id,
          rentAmount,
          payment_reference,
          receipt,
          month,
          payment_year,
          dueDate,
          gracePeriodEnd,
        ]
      );
    }

    res.send(
      `<script>
        alert("Payment uploaded successfully!");
        window.location.href='/finance/upload_payment';
      </script>`
    );
  } catch (error) {
    console.error("Payment upload error:", error);
    res.send(
      `<script>
        alert("Error uploading payment. Please try again.");
        window.history.back();
      </script>`
    );
  }
});

//display stoc usage
router.get("/stock-usage", isAuthenticated("finance"), async (req, res) => {
  const { name = "", start, end } = req.query;

  try {
    let query = `
      SELECT 
        su.id,
        su.item_name,
        su.item_maintenance_type,
        su.requested_maintenance_type,
        su.used_at,
        su.quantity_used,
        si.quantity AS current_stock_quantity,
         
       
        su.maintenance_id,
        su.general_maintenance_id,
        
        si.total_price AS total_price
      FROM stock_usage su
      JOIN stock_items si ON su.item_id = si.id
      WHERE su.item_name LIKE ?
    `;

    const params = [`%${name}%`];

    if (start && end) {
      query += ` AND DATE(su.used_at) BETWEEN ? AND ?`;
      params.push(start, end);
    }

    query += ` ORDER BY su.used_at DESC`;

    const [stockUsage] = await pool.query(query, params);

    const usageWithSource = stockUsage.map((row) => ({
      ...row,
      maintenance_source: row.maintenance_id
        ? "Tenant Request"
        : "General Maintenance",
    }));

    res.render("finance/view_stock", {
      stockUsage: usageWithSource,
      filters: { name, start, end },
    });
  } catch (err) {
    console.error("Error fetching stock usage:", err);
    res.render("finance/view_stock", {
      stockUsage: [],
      error: "Failed to load stock usage data.",
      filters: { name, start, end },
    });
  }
});
//update profile
router.post("/profile-update", isAuthenticated("finance"), async (req, res) => {
  const { old_password, username, password } = req.body;
  const managerId = req.session.user.id; // Assuming session stores manager info

  try {
    // Fetch the current manager's stored password
    const [manager] = await pool.query(
      "SELECT password FROM users WHERE id = ?",
      [managerId]
    );

    if (manager.length === 0) {
      return res.redirect("/finance/profile-update?error=User not found.");
    }

    const storedPassword = manager[0].password;

    // Verify the old password entered by the user
    const match = await bcrypt.compare(old_password, storedPassword);
    if (!match) {
      return res.redirect(
        "/finance/profile-update?error=Incorrect old password."
      );
    }

    let updateFields = [];
    let values = [];

    if (username) {
      updateFields.push("username = ?");
      values.push(username);
    }

    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10);
      updateFields.push("password = ?");
      values.push(hashedPassword);
    }

    values.push(managerId);

    if (updateFields.length > 0) {
      await pool.query(
        `UPDATE users SET ${updateFields.join(", ")} WHERE id = ?`,
        values
      );
    }

    res.redirect(
      "/finance/profile-update?success=Profile updated successfully."
    );
  } catch (err) {
    console.error(err);
    res.redirect("/finance/profile-update?error=Failed to update profile.");
  }
});

// Route to display the finance profile
router.get("/manage-profile", isAuthenticated("finance"), async (req, res) => {
  const managerId = req.session.user.id;

  try {
    const [manager] = await pool.query(
      "SELECT username FROM users WHERE id = ?",
      [managerId]
    );

    if (manager.length === 0) {
      return res.redirect("/finance/dashboard?error=User not found.");
    }

    res.render("finance/manage_profile", {
      user: manager[0], // Only send the username
      error: req.query.error,
      success: req.query.success,
    });
  } catch (err) {
    console.error(err);
    res.redirect("/finance/dashboard?error=Failed to load profile.");
  }
});

module.exports = router;
