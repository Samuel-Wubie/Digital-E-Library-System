const express = require("express");
const pool = require("../db"); // MySQL connection
const isAuthenticated = require("../middleware/auth"); // Import auth middleware
const e = require("express");
const router = express.Router();

router.get("/dashboard", isAuthenticated("stock_manager"), (req, res) => {
  res.render("Stock_dashboard", { username: req.session.user.username });
});
router.get("/stock_menu", isAuthenticated("stock_manager"), (req, res) => {
  res.render("stock/stock_menu", { username: req.session.user.username });
});
// GET: Show Create Stock Form
router.get("/create-stock", isAuthenticated("stock_manager"), (req, res) => {
  res.render("stock/create_stock");
});

// POST: Handle Stock Creation
router.post(
  "/create-stock",
  isAuthenticated("stock_manager"),
  async (req, res) => {
    try {
      let { item_name, maintenance_type, quantity, unit_price } = req.body;

      quantity = parseInt(quantity);
      unit_price = parseFloat(unit_price);

      if (
        !item_name ||
        !maintenance_type ||
        isNaN(quantity) ||
        isNaN(unit_price)
      ) {
        return res
          .status(400)
          .json({ message: "All fields must be filled correctly." });
      }

      const total_price = quantity * unit_price;

      await pool.query(
        `INSERT INTO stock_items (item_name, item_maintenance_type, quantity, unit_price, total_price)
        VALUES (?, ?, ?, ?, ?)`,
        [item_name, maintenance_type, quantity, unit_price, total_price]
      );

      res.status(200).json({ message: "Stock item added successfully!" });
    } catch (err) {
      console.error("Error creating stock:", err);
      res.status(500).json({ message: "Server error while adding stock." });
    }
  }
);

// GET: View all stock items
router.get(
  "/view-stock",
  isAuthenticated("stock_manager"),
  async (req, res) => {
    try {
      const [stockItems] = await pool.query(
        "SELECT * FROM stock_items WHERE quantity > 0 ORDER BY created_at DESC"
      );
      res.render("stock/view_stock", { stockItems });
    } catch (err) {
      console.error("Error fetching stock items:", err);
      res.status(500).send("Server error while fetching stock items.");
    }
  }
);

// GET: View all  used out stock items
router.get(
  "/view-usedout-stock",
  isAuthenticated("stock_manager"),
  async (req, res) => {
    try {
      const [stockItems] = await pool.query(
        "SELECT * FROM stock_items WHERE quantity = 0 ORDER BY created_at DESC"
      );
      res.render("stock/view_used_stock", { stockItems });
    } catch (err) {
      console.error("Error fetching stock items:", err);
      res.status(500).send("Server error while fetching stock items.");
    }
  }
);

module.exports = router;
