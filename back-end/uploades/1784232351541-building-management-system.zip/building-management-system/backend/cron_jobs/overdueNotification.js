const cron = require("node-cron");
const nodemailer = require("nodemailer");
const pool = require("../db");
require("dotenv").config();

const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false,
  pool: true,
  maxConnections: 5,
  maxMessages: 10,
  rateLimit: true,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

// Every minute (for testing); change to "0 8 * * *" for daily at 8AM
cron.schedule("0 8 * * *", async () => {
  console.log("Checking for overdue tenants...");

  try {
    const [tenants] = await pool.query(`
      SELECT id, full_name, email, lease_start, room_number FROM tenants
    `);

    const today = new Date();

    for (const tenant of tenants) {
      // ✅ Skip tenants with no payment history
      const [hasPayments] = await pool.query(
        "SELECT COUNT(*) AS count FROM payments WHERE tenant_id = ?",
        [tenant.id]
      );
      if (hasPayments[0].count === 0) {
        console.log(`Skipping ${tenant.full_name} (no payment history yet)`);
        continue;
      }

      const leaseStart = new Date(tenant.lease_start);
      const current = new Date(
        leaseStart.getFullYear(),
        leaseStart.getMonth(),
        1
      );
      const now = new Date(today.getFullYear(), today.getMonth(), 1);

      while (current <= now) {
        const paymentMonth = current.toLocaleString("default", {
          month: "long",
        });
        const paymentYear = current.getFullYear();

        const graceEnd = new Date(current);
        graceEnd.setDate(graceEnd.getDate() + 5);

        if (today > graceEnd) {
          const [payment] = await pool.query(
            `SELECT * FROM payments
             WHERE tenant_id = ? AND FIND_IN_SET(?, payment_month) > 0
             AND payment_year = ? AND status = 'approved'`,
            [tenant.id, paymentMonth, paymentYear]
          );

          if (payment.length === 0) {
            const mailOptions = {
              from: process.env.EMAIL_USER,
              to: tenant.email,
              subject: "Overdue Rent Payment",
              text: `Dear ${tenant.full_name},\n\nOur records show that your rent for ${paymentMonth} ${paymentYear} (Room ${tenant.room_number}) has not been received and the grace period has passed. Please make the payment as soon as possible.\n\nThank you.`,
            };

            try {
              await transporter.sendMail(mailOptions);
              console.log(
                `Email sent to ${tenant.email} for ${paymentMonth} ${paymentYear}`
              );
              await delay(1000);
            } catch (err) {
              console.error(
                `Failed to send email to ${tenant.email}:`,
                err.message
              );
            }
          }
        }

        current.setMonth(current.getMonth() + 1);
      }
    }
  } catch (error) {
    console.error("Error checking overdue tenants:", error);
  }
});

console.log("Overdue notification cron job started...");
