const mysql = require("mysql2");

// Create a MySQL connection pool
const pool = mysql.createPool({
  host: "localhost",
  user: "root", // Update with your MySQL username
  password: "", // Update with your MySQL password
  database: "property_management", // Name of your database
});

// Export the pool for use in other files
module.exports = pool.promise();
