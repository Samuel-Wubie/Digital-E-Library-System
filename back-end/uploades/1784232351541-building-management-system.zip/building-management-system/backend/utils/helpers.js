// utils/helpers.js

function generatePaymentRef() {
  const date = new Date();
  const uniqueId = Math.floor(Math.random() * 1000000);
  const ref = `${date.getFullYear()}${(date.getMonth() + 1)
    .toString()
    .padStart(2, "0")}${date
    .getDate()
    .toString()
    .padStart(2, "0")}-${uniqueId}`;
  return ref;
}

module.exports = { generatePaymentRef };
