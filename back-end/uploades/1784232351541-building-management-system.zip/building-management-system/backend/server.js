const express = require("express");
const session = require("express-session");
const multer = require("multer");
const path = require("path");
const tenantRoutes = require("./routes/tenant");
const authRoutes = require("./routes/auth");
const managerRoutes = require("./routes/manager");
const ownerRoutes = require("./routes/owner");
const finaceRoutes = require("./routes/finance");
const StockRoutes = require("./routes/stock");
require("./cron_jobs/overdueNotification");

const pool = require("./db"); // MySQL connection

// Initialize app
const app = express();

// Set EJS as the view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views")); // Set the 'views' directory to where your EJS files are stored
app.set("view cache", false); // Disable caching during development
app.use("/public", express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
// Middleware to parse JSON requests
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(
  session({
    secret: "your-secret-key", // You can change this to a random string
    resave: false,
    saveUninitialized: true,
  })
);

// Use routes for tenants and auth
app.use("/api/tenant", tenantRoutes);
app.use("/api/auth", authRoutes);
app.use("/manager", managerRoutes);
app.use("/owner", ownerRoutes);
app.use("/manager", managerRoutes);
app.use("/tenant", tenantRoutes);
app.use("/finance", finaceRoutes);
app.use("/stock", StockRoutes);

// Simple route to test server
app.get("/", (req, res) => {
  res.render("login"); // Render the login.ejs file when accessing '/'
});
app.get("/login", (req, res) => {
  res.render("login"); // Render the login.ejs file when accessing '/'
});
app.get("/register", (req, res) => {
  res.render("register"); // Render the login.ejs file when accessing '/'
});

app.get("/manager/dashboard", (req, res) => {
  // Set Cache-Control headers to prevent caching
  res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  res.setHeader("Pragma", "no-cache"); // For older browsers
  res.setHeader("Expires", "0");

  if (req.session.user && req.session.user.role === "manager") {
    res.render("manager/dashboard", { username: req.session.user.username });
  } else {
    res.redirect("/login");
  }
});

// Test the MySQL connection
pool
  .getConnection()
  .then((connection) => {
    console.log("Database connected successfully");
    connection.release(); // Release the connection back to the pool
  })
  .catch((err) => {
    console.error("Database connection failed", err);
  });

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
