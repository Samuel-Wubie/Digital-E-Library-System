module.exports = function roleCheck(requiredRole) {
  return (req, res, next) => {
    if (!req.session.user) {
      return res.redirect("/login");
    }

    if (req.session.user.role !== requiredRole) {
      return res.status(403).send("Access Denied");
    }

    next();
  };
};
