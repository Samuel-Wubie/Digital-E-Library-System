const isAuthenticated = (role) => {
  return (req, res, next) => {
    if (req.session.user && req.session.user.role === role) {
      return next(); // User is authenticated, proceed to the route
    }
    res.redirect("/login"); // Redirect to login if not authenticated
  };
};

module.exports = isAuthenticated;
